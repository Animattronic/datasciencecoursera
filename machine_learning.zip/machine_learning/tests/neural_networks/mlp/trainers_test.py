__author__ = 'Filip'

import unittest
import numpy as np
import core.neural_networks.activation_functions as activations
import core.utils.error_functions as error_functions
import core.neural_networks.error_functions as errors
import core.utils.quality as quality
import core.neural_networks.mlp.models as models
import core.neural_networks.mlp.backpropagation_models as bp
import core.neural_networks.mlp.trainers as trainers
import core.optimization.particle_swarm as swarm
import core.training.training_strategies as strategies

class NeuralNetworksTrainersTests(unittest.TestCase):

    def setUp(self):
        self.data = np.loadtxt("iris.txt", delimiter=",")
        self.dependent_indices = [4, 5, 6]

    def test_classification_backpropagation_trainer(self):
        # Given
        inputs_count = 4
        hidden_layers_count = 1
        hidden_neurons_count = 6
        outputs_count = 3
        logger = quality.QualityLogger()
        factory = bp.BackpropagationLayerFactory()
        error_function = errors.MeanSquareError()
        network = bp.BackPropagationNetwork(
            inputs_count,
            hidden_layers_count,
            hidden_neurons_count,
            outputs_count,
            activations.HyperTangentActivationFunction(),
            activations.SoftmaxActivaitonFunction(),
            error_function,
            factory)
        strategy = strategies.KFoldingCrossValidation(900, 5, 0.8)
        trainer = trainers.BackPropagationTrainer(error_functions.mean_square_errors, logger, strategy)

        # When
        trainer.train(self.data[:,[0,1,2,3]], self.data[:,self.dependent_indices], network, [(-10.0, 10.0)] * 51)

        # Then
        data = self.data[:,[0,1,2,3]]
        expected = self.data[:,[4,5,6]]
        correct = 0
        incorrect = 0
        for i in range(len(data)):
            x = data[i,:].reshape((1, 4))
            y = expected[i, :]
            actual = network.calculate_outputs(x)
            max_actual = np.argmax(actual)
            max_expected = np.argmax(y)
            if max_actual == max_expected:
                correct += 1
            else:
                incorrect += 1
        correct_classifications = (correct / (correct + incorrect))
        print(correct_classifications)
        self.assertTrue(correct_classifications >= 0.9)

    def test_setup_network_wights(self):
        # Given
        inputs_count = 2
        hidden_layers_count = 2
        hidden_neurons_count = 2
        outputs_count = 3
        factory = models.NetworkLayerFactory()
        error_function = errors.MeanSquareError()
        network = models.NeuralNetwork(
            inputs_count,
            hidden_layers_count,
            hidden_neurons_count,
            outputs_count,
            activations.BipolarActivation,
            activations.BipolarActivation,
            error_function,
            factory)
        trainer = trainers.OptimizationBasedTrainer(None, strategies.HoldOutTraining(100, 0.75), 100, error_functions.mean_square_errors, quality.QualityLogger())

        weights = list(range(0, 21))

        # When
        trainer.setup_network_weights(network, weights)

        # Then
        self.assertEqual(0, network[0].next_layer_weights[0,0])

    def test_classification_optimization_trainer(self):
        # Given
        inputs_count = 4
        hidden_layers_count = 1
        hidden_neurons_count = 6
        outputs_count = 3
        logger = quality.QualityLogger()
        factory = models.NetworkLayerFactory()
        error_function = errors.MeanSquareError()
        network = models.NeuralNetwork(
            inputs_count,
            hidden_layers_count,
            hidden_neurons_count,
            outputs_count,
            activations.HyperTangentActivationFunction(),
            activations.SoftmaxActivaitonFunction(),
            error_function,
            factory)
        particle_swarm = swarm.ParticleSwarm(10)

        trainer = trainers.OptimizationBasedTrainer(particle_swarm, strategies.HoldOutTraining(1, 0.75), 100, error_functions.mean_square_errors, logger)

        # When
        trainer.train(self.data[:,[0,1,2,3]], self.data[:, self.dependent_indices], network, [(-10.0, 10.0)] * 51)

        # Then
        data = self.data[:,[0,1,2,3]]
        expected = self.data[:,[4,5,6]]
        correct = 0
        incorrect = 0
        for i in range(len(data)):
            x = data[i,:].reshape((1, 4))
            y = expected[i, :]
            actual = network.calculate_outputs(x)
            max_actual = np.argmax(actual)
            max_expected = np.argmax(y)
            if max_actual == max_expected:
                correct += 1
            else:
                incorrect += 1
        correct_classifications = (correct / (correct + incorrect))
        print(correct_classifications)
        self.assertTrue(correct_classifications >= 0.9)

if __name__ == '__main__':
    unittest.main()
