__author__ = 'Filip'

import unittest
import numpy as np
import core.neural_networks.mlp.models as models
import core.neural_networks.mlp.backpropagation_models as bp
import core.neural_networks.activation_functions as activations
import core.neural_networks.error_functions as errors


class BackpropagationModelsTests(unittest.TestCase):

    def test_calculate_gradients_output_layer(self):
        # Given
        layer = bp.BackpropagationOutputLayer(2, 2, activations.SigmoidActivationFunction())
        layer.calculate_output(np.mat([2.0, 3.0]))
        error_function = errors.MeanSquareError()
        expected_gradients = [-0.0085, -0.0196]

        # When
        layer.calculate_gradients(np.array([0.8, 0.5]), error_function)

        # Then
        actual_gradient_1 = layer.gradients[0,0]
        actual_gradient_2 = layer.gradients[0,1]

        self.assertAlmostEqual(expected_gradients[0], actual_gradient_1, delta=0.0006)
        self.assertAlmostEqual(expected_gradients[1], actual_gradient_2, delta=0.0006)

    def test_calculate_gradients_hidden_layer(self):
        # Given
        layer = bp.BackpropagationHiddenLayer(2, 2, activations.HyperTangentActivationFunction())
        layer.next_layer_weights = np.arange(1, 5).reshape((2,2))
        error_function = errors.MeanSquareError()
        layer.calculate_output(np.array([4.0, 4.0]))
        expected_gradients = [0.024, 0.065]

        # When
        layer.calculate_gradients(np.array([10.0, 5.0]).reshape((1,2)), error_function)

        #Then
        actual_gradient_1 = layer.gradients[0,0]
        actual_gradient_2 = layer.gradients[0,1]

        self.assertAlmostEqual(expected_gradients[0], actual_gradient_1, delta=0.01)
        self.assertAlmostEqual(expected_gradients[1], actual_gradient_2, delta=0.01)

    def test_calculate_weights_updates_hidden_layer(self):
         # Given
        layer = bp.BackpropagationHiddenLayer(2, 2, activations.HyperTangentActivationFunction())
        layer.next_layer_weights = np.arange(1, 5).reshape((2,2))
        layer.previous_weights_delta = np.arange(0.1, 0.5, 0.1).reshape((2,2))

        error_function = errors.MeanSquareError()
        layer.calculate_output(np.array([50.0, 50.0]))

        expected_next_layer_weight = np.array([
            [ 2.1, 4.2 ],
            [ 4.3, 6.4 ]
        ])
        expected_weights_delta = np.array([
            [ 1.0, 2.0 ],
            [ 1.0, 2.0 ],
        ])
        # When
        layer.update_weights(np.array([ 1.0, 2.0 ]).reshape(1,2), 1.0, 1.0)

        #Then
        self.assertTrue(np.array_equal(expected_next_layer_weight, layer.next_layer_weights))

    def test_calculate_weights_updates_input_layer(self):
         # Given
        layer = bp.BackPropagationInputLayer(2, 2, activations.HyperTangentActivationFunction())
        layer.next_layer_weights = np.arange(1.0, 5.0).reshape((2,2))
        layer.previous_weights_delta = np.arange(0.1, 0.5, 0.1).reshape((2,2))

        error_function = errors.MeanSquareError()
        layer.calculate_output(np.array([50.0, 50.0]).reshape((1, 2)))

        expected_next_layer_weight = np.array([
            [ 2.1, 4.2 ],
            [ 4.3, 6.4 ]
        ])
        expected_weights_delta = np.array([
            [ 1.0, 2.0 ],
            [ 1.0, 2.0 ],
        ])
        # When
        layer.update_weights(np.array([ 1.0, 2.0 ]).reshape(1,2), 1.0, 1.0)

    def test_calculate_biases_updates_hidden_layer(self):
         # Given
        layer = bp.BackpropagationHiddenLayer(2, 2, activations.HyperTangentActivationFunction())

        layer.biases = np.array([1.0, 1.0]).reshape(1, 2)
        layer.previous_biases_delta = np.array([ 0.1, 0.2 ]).reshape(1, 2)
        layer.gradients = np.array([ 0.5, 0.5 ]).reshape(1, 2)

        error_function = errors.MeanSquareError()

        expected_biases = np.array([ 1.6, 1.7 ]).reshape(1, 2)
        expected_biases_delta = np.array([ 0.5, 0.5 ]).reshape(1, 2)

        # When
        layer.update_biases(1.0, 1.0)

        #Then
        self.assertTrue(np.array_equal(expected_biases, layer.biases))
        self.assertTrue(np.array_equal(expected_biases_delta, layer.previous_biases_delta))

    def test_perform_backpropagation_test(self):
        # Given
        inputs_count = 3
        hidden_neurons_count = 4
        outputs_count = 2
        hidden_layers_count = 1
        input_hidden_weights = np.arange(0.001, 0.013, 0.001).reshape((inputs_count, hidden_neurons_count))
        hidden_biases = np.arange(0.013, 0.016, 0.001).reshape((1, hidden_neurons_count))
        hidden_outputs_weights = np.arange(0.017, 0.025, 0.001).reshape((hidden_neurons_count, outputs_count))
        outputs_biases = np.arange(0.025, 0.027, 0.001).reshape((1,outputs_count))

        subject = bp.BackPropagationNetwork(
            inputs_count,
            hidden_layers_count,
            hidden_neurons_count,
            outputs_count,
            activations.HyperTangentActivationFunction(),
            activations.SigmoidActivationFunction(),
            errors.MeanSquareError(),
            bp.BackpropagationLayerFactory()
        )

        subject[0].next_layer_weights = input_hidden_weights
        subject[1].biases = hidden_biases
        subject[1].next_layer_weights = hidden_outputs_weights
        subject[2].biases = outputs_biases

        inputs = np.array([ 1.0, -2.0, -3.0 ]).reshape((1, 3))
        targets = np.array([ 0.1234, 0.8766 ]).reshape((1, 2))

        # When
        subject.calculate_outputs(inputs)
        subject.perform_backpropagation(targets, 1.0, 1.0)

        # Then
        print(subject)

if __name__ == '__main__':
    unittest.main()
