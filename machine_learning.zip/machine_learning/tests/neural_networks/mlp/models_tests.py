__author__ = 'Filip'

import unittest
import numpy as np
import core.neural_networks.mlp.models as models
import core.neural_networks.activation_functions as activations
import core.neural_networks.error_functions as errors

class ModelsTester(unittest.TestCase):

    def test_network_construction(self):
        # Given
        factory = models.NetworkLayerFactory()
        inputs_count = 3
        hidden_layers_count = 2
        hidden_neurons_count = 5
        outputs_count = 2
        error_function = errors.MeanSquareError()

        # When
        network = models.NeuralNetwork(
            inputs_count,
            hidden_layers_count,
            hidden_neurons_count,
            outputs_count,
            activations.HyperTangentActivationFunction(),
            activations.SoftmaxActivaitonFunction(),
            error_function,
            factory)

        # Then
        self.assertEqual(hidden_layers_count + 2, network.layers_count)

        # input layer
        self.assertEqual(inputs_count, network[0].neurons_count)
        self.assertEqual(hidden_neurons_count, network[0].next_layer_neurons_count)
        self.assertTrue(np.all(0 < network[0].next_layer_weights))
        self.assertTrue(np.all(network[0].next_layer_weights < 0.1))
        self.assertTrue(np.all(0 < network[0].biases))
        self.assertTrue(np.all(network[0].biases < 0.1))

        # 1st hidden layer
        self.assertEqual(hidden_neurons_count, network[1].neurons_count)
        self.assertEqual(hidden_neurons_count, network[1].next_layer_neurons_count)
        self.assertTrue(np.all(0 < network[1].next_layer_weights))
        self.assertTrue(np.all(network[1].next_layer_weights < 0.1))
        self.assertTrue(np.all(0 < network[1].biases))
        self.assertTrue(np.all(network[1].biases < 0.1))

        # 2nd hidden layer
        self.assertEqual(hidden_neurons_count, network[2].neurons_count)
        self.assertEqual(outputs_count, network[2].next_layer_neurons_count)
        self.assertTrue(np.all(0 < network[2].next_layer_weights))
        self.assertTrue(np.all(network[2].next_layer_weights < 0.1))
        self.assertTrue(np.all(0 < network[2].biases))
        self.assertTrue(np.all(network[2].biases < 0.1))

        # outputs layer
        self.assertEqual(outputs_count, network[3].neurons_count)


    def test_calculate_outputs(self):
        # Given
        hidden_layers_count = 1
        hidden_neurons_count = 2
        inputs_count = 2
        outputs_count = 2
        activation_function = activations.BipolarActivation()
        factory = models.NetworkLayerFactory()
        error_function = errors.MeanSquareError()
        inputs = np.array([2, -3]).reshape((1,2))

        expected_outputs = np.array([-1,1]).reshape((1,2))

        subject = models.NeuralNetwork(
            inputs_count,
            hidden_layers_count,
            hidden_neurons_count,
            outputs_count,
            activation_function,
            activation_function,
            error_function,
            factory)

        subject[0].next_layer_weights = np.array([
            [4,2],
            [1,3]
        ])
        subject[0].biases = np.array([1,2]).reshape((1,2))

        subject[1].next_layer_weights = np.array([
            [1,4],
            [3,2]
        ])
        subject[1].biases = np.array([1,1]).reshape((1,2))

        subject[2].biases = np.array([0,0]).reshape((1,2))

        # When
        actual_outputs = subject.calculate_outputs(inputs)

        # Then
        self.assertTrue(np.array_equal(expected_outputs, actual_outputs))


if __name__ == '__main__':
    unittest.main()
