__author__ = 'Filip'

import unittest
import core.neural_networks.activation_functions as activations
import numpy as np
import math

class ActivationFunctionTests(unittest.TestCase):

    def setUp(self):
        self.softmax = activations.SoftmaxActivaitonFunction()
        self.hyperTanh = activations.HyperTangentActivationFunction()
        self.bipolar = activations.BipolarActivation()

    def test_bipolar_activation(self):
        # Given
        inputs = np.array([-0.1, 0.1, -0.1])
        expected = np.array([-1.0, 1.0, -1.0])

        # when
        actual = self.bipolar.calculate_output(inputs)

        # then
        for elem_with_idx in enumerate(expected):
            idx = elem_with_idx[0]
            elem = elem_with_idx[1]
            actual_elem = actual[idx]
            self.assertAlmostEqual(round(elem, 2), round(actual_elem, 2), 3)

    def test_softmax_activation(self):
        # Given
        inputs = np.array([0.5, 0.6, 0.7])
        expected = np.array([0.3001, 0.332, 0.367])

        # when
        actual = self.softmax.calculate_output(inputs)

        # then
        for elem_with_idx in enumerate(expected):
            idx = elem_with_idx[0]
            elem = elem_with_idx[1]
            self.assertAlmostEqual(round(elem, 2), round(actual[idx,0], 2), 3)

    def test_softmax_derivative(self):
        # Given
        inputs = np.array([0.5, 0.6, 0.7]).reshape((1, 3))
        expected = np.array([0.62, 0.65, 0.67]).reshape((1,3))

        # when
        actual = self.softmax.calculate_derivative(inputs)

        # then
        for col_idx in range(expected.shape[1]):
            elem = expected[0, col_idx]
            self.assertAlmostEqual(round(elem, 2), round(actual[0, col_idx], 2), 2)

    def test_hypertanh_activation(self):
        # Given
        inputs = np.array([0.5, 0.6, 0.7])
        expected = np.array([0.462, 0.537, 0.604])

        # when
        actual = self.hyperTanh.calculate_output(inputs)

        # then
        for elem_with_idx in enumerate(expected):
            idx = elem_with_idx[0]
            elem = elem_with_idx[1]
            self.assertAlmostEqual(round(elem, 2), round(actual[idx], 2), 3)

    def test_hypertanh_derivative(self):
        # Given
        inputs = np.array([0.5, 0.6, 0.7])
        expected = np.array([0.75, 0.64, 0.51])

        # when
        actual = self.hyperTanh.calculate_derivative(inputs)

        # then
        for elem_with_idx in enumerate(expected):
            idx = elem_with_idx[0]
            elem = elem_with_idx[1]
            self.assertAlmostEqual(round(elem, 2), round(actual[idx], 2), 2)

if __name__ == '__main__':
    unittest.main()
