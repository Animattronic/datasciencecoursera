__author__ = 'Filip'

import unittest
import numpy as np
import scipy.spatial.distance as dist
import core.instance_based_learning.knn as knn
import core.instance_based_learning.feature_selectors as selectors

class TestFeatureSelection(unittest.TestCase):

    def test_features_selection(self):
        # Given
        data = np.mat([
            [ 1.0, 1.0, 1.0, 10.0, 100.0 ],
            [ 1.7, 1.7, 1.7, 17.0, 170.0 ],
            [ 1.3, 1.3, 1.3, 13.0, 130.0 ],
            [ 1.2, 1.2, 1.2, 12.0, 120.0 ],
            [ 1.6, 1.6, 1.6, 16.0, 160.0 ],
            [ 3.3, 3.3, 3.3, 33.0, 330.0 ],
            [ 3.1, 3.1, 3.1, 31.0, 310.0 ],
            [ 3.8, 3.8, 3.8, 38.0, 380.0 ],
            [ 3.5, 3.5, 3.5, 35.0, 350.0 ],
            [ 3.9, 3.9, 3.9, 39.0, 390.0 ],
            [ 6.1, 6.1, 6.1, 61, 610],
            [ 6.2, 6.2, 6.2, 62, 620],
            [ 6.3, 6.3, 6.3, 63, 630],
            [ 6.5, 6.5, 6.5, 65, 650],
            [ 6.8, 6.8, 6.8, 68, 680]
        ])
        nrow, ncol = data.shape
        random_matrix = np.random.rand(nrow, 50) * 50
        data = np.hstack((random_matrix, data))
        expected = data[:, -1]
        data = np.delete(data, -1, axis=1)

        query = np.array([ 3.65, 3.65, 3.65, 36.5 ])
        random_vec = np.random.rand(50) * 50
        query = np.hstack((random_vec, query))

        expected_selected_features = { 50, 51 }
        expected_classification_result = 368.81

        knn_classifier = knn.KnnClassifier(dist.euclidean, knn.squared_inverse_of_distance_weight)
        evaluator = selectors.KnnEvaluator(knn_classifier, 3)
        subject = selectors.ForewardSelector(evaluator)

        # When
        actual_selected_features = list(subject.select_features(data, expected))
        classification_result = knn_classifier.process_query(
            data[:,
            actual_selected_features],
            expected,
            query[actual_selected_features],
            3)

        # Then
        self.assertEqual( expected_selected_features, set(actual_selected_features) )
        self.assertAlmostEqual(expected_classification_result, classification_result, 2)

    def test_instances_selection(self):
        # Given
        data = np.mat([
            [ 1.0, 1.0, 1.0, 10.0, 100.0 ],
            [ 1.1, 1.1, 1.1, 11.0, 110.0 ],
            [ 1.7, 1.7, 1.7, 17.0, 170.0 ],
            [ 1.8, 1.8, 1.8, 18.0, 180.0 ],
            [ 1.3, 1.3, 1.3, 13.0, 130.0 ],
            [ 1.4, 1.4, 1.4, 14.0, 140.0 ],
            [ 1.2, 1.2, 1.2, 12.0, 120.0 ],
            [ 1.6, 1.6, 1.6, 16.0, 160.0 ],
            [ 1.61, 1.61, 1.61, 16.1, 161.0 ],
            [ 3.31, 3.31, 3.31, 33.1, 331.0 ],
            [ 3.2, 3.2, 3.2, 32.0, 320.0 ],
            [ 3.21, 3.21, 3.21, 32.1, 321.0 ],
            [ 3.1, 3.1, 3.1, 31.0, 310.0 ],
            [ 3.8, 3.8, 3.8, 38.0, 380.0 ],
            [ 3.5, 3.5, 3.5, 35.0, 350.0 ],
            [ 3.9, 3.9, 3.9, 39.0, 390.0 ],
            [ 6.1, 6.1, 6.1, 61, 610],
            [ 6.2, 6.2, 6.2, 62, 620],
            [ 6.3, 6.3, 6.3, 63, 630],
            [ 6.5, 6.5, 6.5, 65, 650],
            [ 6.8, 6.8, 6.8, 68, 680]
        ])
        nrow, ncol = data.shape
        expected = data[:, -1]
        data = np.delete(data, -1, axis=1)

        query = np.array([ 3.65, 3.65, 3.65, 36.5 ])

        knn_classifier = knn.KnnClassifier(dist.euclidean, knn.squared_inverse_of_distance_weight)
        evaluator = selectors.KnnEvaluator(knn_classifier, 3)
        subject = selectors.InstancesSelector(evaluator, 5)

        expected_selected_instances = [0, 1, 2, 3, 4, 5, 7, 9, 10, 12, 13, 14, 15, 16, 17, 18, 19, 20]

        # When
        actual_selected_instances = list(subject.select_instances(data, expected))
        self.assertEqual(expected_selected_instances, actual_selected_instances)

if __name__ == '__main__':
    unittest.main()
