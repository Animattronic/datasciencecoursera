__author__ = 'Filip'

import unittest
import core.instance_based_learning.knn as knn
import numpy as np
import scipy.spatial.distance as dist

class KnnTester(unittest.TestCase):

    def test_knn(self):
        # Given
        data = np.mat([
            [ 1.0, 1.0, 1.0, 10.0, 100.0 ],
            [ 1.7, 1.7, 1.7, 17.0, 170.0 ],
            [ 1.3, 1.3, 1.3, 13.0, 130.0 ],
            [ 1.2, 1.2, 1.2, 12.0, 120.0 ],
            [ 1.6, 1.6, 1.6, 16.0, 160.0 ],
            [ 3.3, 3.3, 3.3, 33.0, 330.0 ],
            [ 3.1, 3.1, 3.1, 31.0, 310.0 ],
            [ 3.8, 3.8, 3.8, 38.0, 380.0 ],
            [ 3.5, 3.5, 3.5, 35.0, 350.0 ],
            [ 3.9, 3.9, 3.9, 39.0, 390.0 ],
            [ 6.1, 6.1, 6.1, 61, 610],
            [ 6.2, 6.2, 6.2, 62, 620],
            [ 6.3, 6.3, 6.3, 63, 630],
            [ 6.5, 6.5, 6.5, 65, 650],
            [ 6.8, 6.8, 6.8, 68, 680]
        ])
        values = data[:, 4]
        query = np.array([ 3.65, 3.65, 3.65, 36.5 ])
        subject = knn.KnnClassifier(dist.euclidean, knn.squared_inverse_of_distance_weight)
        expected = 368.81

        # When
        actual_result = subject.process_query(data[:, :4], values, query, 3)

        # Then
        self.assertAlmostEqual(expected, actual_result, places=2)

if __name__ == '__main__':
    unittest.main()
