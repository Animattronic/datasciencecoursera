__author__ = 'Filip'

import unittest
import pandas as pd
import core.decision_trees.models as models
import core.decision_trees.evaluators as evaluators
import core.decision_trees.dispersion_measures as entropy


class EvaluatorsTests(unittest.TestCase):

    def setUp(self):
        self.data = pd.DataFrame({
            'day': ['07-05', '07-06', '07-07', '07-09', '07-10', '07-12', '07-14', '07-15', '07-20', '07-21', '07-22', '07-23', '07-26', '07-30'],
            'temperature': ['hot', 'hot', 'hot', 'cool', 'cool', 'mild', 'cool', 'mild', 'mild', 'mild', 'hot', 'mild', 'cool', 'mild'],
            'outlook': ['sunny', 'sunny', 'overcast', 'rain', 'overcast', 'sunny', 'sunny', 'rain', 'sunny', 'overcast', 'overcast', 'rain', 'rain', 'rain'],
            'humidity': ['high', 'high', 'high', 'normal', 'normal', 'high', 'normal', 'normal', 'normal', 'high', 'normal', 'high', 'normal', 'high'],
            'windy': [False, True, False, False, True, False,False,False, True, True,False, True, True, False],
            'play' : [False, False, True, True, True, False, True,True,True,True,True,False, False, True]
        })
        self.weather_data = pd.DataFrame({
            'weather': ['sunny', 'sunny', 'overcast', 'rain', 'rain', 'rain', 'overcast', 'sunny', 'sunny', 'rain', 'sunny', 'overcast', 'overcast', 'rain'],
            'temperature': [27,28,29,21,17,18,19,22,20,23,24,25,30,26],
            'humidity': [55,60,65,70,20,25,30,75,35,40,45,80,50,85],
            'wind': [2,10,3,4,5,12,14,6,7,8,16,18,9,20],
            'play': [False, False, True, True, True, False, True, False, True, True, True, True, True, False]
        })
        self.numeric_splitter = evaluators.NumericSplitSelector()
        self.simple_information_gain_calculator = evaluators.SimpleInformationGainCalculator()
        self.gain_ratio_calculator = evaluators.InformationGainRatioCalculator()
        self.multi_splitter = evaluators.MultiValueSplitSelector(self.numeric_splitter, entropy.shannon_entropy, self.gain_ratio_calculator)
        self.binary_splitter = evaluators.BinarySplitSelector(self.numeric_splitter, entropy.shannon_entropy, self.gain_ratio_calculator)

    def test_simple_information_gain(self):
        # Given
        unique_outlook_values = self.data['outlook'].unique()
        splitted_data = [self.data[self.data['outlook'] == value] for value in unique_outlook_values]
        expected_gain = 0.247

        # When
        actual_gain = self.simple_information_gain_calculator.calculate_information_gain(
            self.data,
            splitted_data,
            entropy.shannon_entropy,
            'play')

        # Then
        self.assertAlmostEqual(expected_gain, actual_gain, 3)

    def test_gain_ratio(self):
        # Given
        unique_outlook_values = self.data['outlook'].unique()
        splitted_data = [self.data[self.data['outlook'] == value] for value in unique_outlook_values]
        expected_gain = 0.156

        # When
        actual_gain = self.gain_ratio_calculator.calculate_information_gain(
            self.data,
            splitted_data,
            entropy.shannon_entropy,
            'play')

        # Then
        self.assertAlmostEqual(expected_gain, actual_gain, 3)

    def test_multi_value_split(self):
        # Given
        actual_split_option = self.multi_splitter.select_best_split_data(self.data, 'play')
        expected_split_option = models.SplitOption('day')

        # Then
        self.assertEquals(expected_split_option, actual_split_option)

    def test_numeric_attribute_split(self):
        # Given
        subject = self.numeric_splitter
        split_attr = 'temperature'
        expected_split_option = models.SplitOption('temperature', 27.5, True)
        expected_information_gain = 0.169

        # When
        actual_split_option, actual_information_gain = subject.select_best_numeric_split(self.weather_data, 'play', split_attr, entropy.shannon_entropy, self.gain_ratio_calculator)

        # Then
        self.assertEquals(expected_split_option, actual_split_option)
        self.assertAlmostEqual(expected_information_gain, actual_information_gain, 2)

    def test_multi_value_splitter_with_numeric_split(self):
        # Given
        subject = self.multi_splitter
        expected_best_split_option = models.SplitOption('humidity', 82.5, True)
        # When
        actual_best_split_option = subject.select_best_split_data(self.weather_data, 'play')

        # Then
        self.assertEquals(expected_best_split_option, actual_best_split_option)


if __name__ == '__main__':
    unittest.main()
