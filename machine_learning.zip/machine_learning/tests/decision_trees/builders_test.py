__author__ = 'Filip'

import unittest
import pandas as pd
import numpy as np
import sklearn.datasets as data
import core.decision_trees.dispersion_measures as dispersion
import core.decision_trees.evaluators as evaluators
import core.decision_trees.builders as builders


class TestBuilders(unittest.TestCase):
    def setUp(self):
        self.test_data = pd.DataFrame({
            'gender': ['male', 'male', 'female', 'female', 'male', 'male', 'female', 'female', 'male', 'female'],
            'car_ownership': ['0', '1', '1', '0', '1', '0', '1', '1', '2', '2'],
            'travel_cost': ['cheap', 'cheap', 'cheap', 'cheap', 'cheap', 'standard', 'standard', 'expensive', 'expensive', 'expensive'],
            'income_level': ['low', 'medium', 'medium', 'low', 'medium', 'medium', 'medium', 'high', 'medium', 'high'],
            'transportation_mode': ['bus', 'bus', 'train', 'bus', 'bus', 'train', 'train', 'car', 'car', 'car']
        })

    def test_building(self):
        # Given
        split_selector = evaluators.MultiValueSplitSelector(
            evaluators.NumericSplitSelector(),
            dispersion.shannon_entropy,
            evaluators.SimpleInformationGainCalculator())
        subject = builders.DecisionTreeBuilder(split_selector)
        query = pd.DataFrame({
            'gender': ['female'],
            'car_ownership': ['1'],
            'travel_cost': ['cheap'],
            'income_level': ['medium'],
            'transportation_mode': [None]
        })

        # When
        tree = subject.build_model(self.test_data, 'transportation_mode')
        predictor = evaluators.Predictor(tree, 'transportation_mode')

        # Then
        print(predictor.predict(query))


if __name__ == '__main__':
    unittest.main()
