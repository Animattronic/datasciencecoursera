__author__ = 'Filip'

import unittest
import core.decision_trees.models as models


class ModelsTester(unittest.TestCase):
    def test_something(self):
        self.assertEqual(True, False)


if __name__ == '__main__':
    unittest.main()
