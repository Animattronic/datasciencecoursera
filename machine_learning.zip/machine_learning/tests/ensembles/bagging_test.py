__author__ = 'Filip'

import unittest
import pandas as pd
import numpy as np
import core.decision_trees.models as models
import core.decision_trees.builders as builders
import core.decision_trees.evaluators as evaluators
import core.decision_trees.dispersion_measures as dispersion
import core.ensembles.bagging as bagging
import sklearn.datasets as data


class MyTestCase(unittest.TestCase):

    def predictor_factory(self, decision_tree, decision_value):
        return evaluators.Predictor(decision_tree, decision_value)

    def test_bagging_iris_dataset(self):
        # Given
        split_selector = evaluators.MultiValueSplitSelector(
            evaluators.NumericSplitSelector(),
            dispersion.gini_index,
            evaluators.InformationGainRatioCalculator())
        subject = builders.DecisionTreeBuilder(split_selector)
        targets = data.load_iris().target
        iris = data.load_iris().data
        iris_data = pd.DataFrame({
            'sepal length': iris[:, 0],
            'sepal width': iris[:, 1],
            'petal length': iris[:, 2],
            'petal width': iris[:, 3],
            'target': targets})
        training_data_indices = np.random.choice(list(range(0, 150)), size=100, replace=True)
        test_data_indices = iris_data.index - training_data_indices

        training_data = iris_data.loc[training_data_indices]
        test_data = iris_data.loc[test_data_indices]

        bagged_model = bagging.Bagger(subject, bag_size=1000)
        bagging_results = bagged_model.build_model(training_data, 'target')
        bagging_predictor = bagging.BaggingPredictor(bagging_results, 'target', self.predictor_factory)

        correct = 0
        incorrect = 0
        predicted_results = bagging_predictor.predict(test_data)
        index = -1
        for idx, row in test_data.iterrows():
            index += 1
            expected_result = row['target']
            actual_result = predicted_results[index]
            print(str.format("Expected: {0} Actual: {1}", expected_result, actual_result))
            if expected_result == actual_result:
                correct += 1
            else:
                incorrect += 1
        print("--------")
        print(correct/(correct + incorrect))




if __name__ == '__main__':
    unittest.main()
