__author__ = 'Filip'

import unittest
import core.rule_induction.learners as learners
import core.rule_induction.models as models
import core.rule_induction.heuristics as heuristics
import tests.rule_induction.test_data as test_data

import pandas as pd

class LearnersTest(unittest.TestCase):

    def test_aq_partial_star(self):
        # Given
        subject = learners.AQAlgorithm(None, None, None)
        positive_seed_idx = 2
        negative_seed_idx = 1
        data = test_data.discrete_weather_data
        column_domains = {column: set(data[column].unique()) for column in data.columns if column != 'play'}
        expected_outlook_complex = models.Complex(
            models.Inclusion('outlook', 'overcast', 'rainy'))
        expected_wind_complex = models.Complex(models.Inclusion('wind', 'mild'))

        # When
        actual_star = subject.partial_star(
            positive_seed_idx,
            negative_seed_idx,
            data,
            column_domains,
            dict())

        # Then
        actual_outlook_complex = [complex for complex in actual_star if 'outlook' in complex.covered_attributes][0]
        self.assertEqual(expected_outlook_complex, actual_outlook_complex)

        actual_wind_complex = [complex for complex in actual_star if 'wind' in complex.covered_attributes][0]
        self.assertEqual(expected_wind_complex, actual_wind_complex)

    def test_remove_less_general_complexes(self):
        # Given
        subject = learners.AQAlgorithm(None, None, None)
        c1 = models.Complex(models.Inclusion('a', 1,2,3))
        c2 = models.Complex(models.Inclusion('b', 1,2,3))
        c3 = models.Complex(models.Inclusion('c', 1,2,3))
        c4 = models.Complex(models.Inclusion('d', 1,2,3))
        complexes_covering = {
            c1: set([1,2,3,4]),
            c2: set([2,3]),
            c3: set([4]),
            c4: set([3,4,5])
        }
        expected_complexes = {
            c1: set([1,2,3,4]),
            c4: set([3,4,5])
        }

        # When
        actual_complexes = subject.remove_less_general_complexes(complexes_covering)

        # Then
        self.assertDictEqual(expected_complexes, actual_complexes)

    def test_intersect_partial_star_with_complexes_so_far(self):
        # Given
        subject = learners.AQAlgorithm(None, None, None)
        c1 = models.Complex(models.Inclusion('outlook', 'sunny', 'overcast'))
        c2 = models.Complex(models.Inclusion('temperature', 'moderate', 'warm'))
        c3 = models.Complex(models.Inclusion('humidity', 'high'))
        complex_so_far = models.Complex(
            models.Inclusion('outlook', 'sunny', 'rainy'),
            models.Inclusion('temperature', 'cold', 'warm'))
        complexes_so_far = {complex_so_far: [0, 1]}
        partial_star = [c1, c2, c3]

        expected_complex = models.Complex(
            models.Inclusion('outlook', 'sunny'),
            models.Inclusion('temperature', 'cold', 'warm')
        )
        expected_covering = {0, 1, 8}
        # When
        intersected_complex = subject.intersect_new_partial_star_and_complexes_so_far(partial_star, complexes_so_far, test_data.discrete_weather_data)

        # Then
        self.assertEqual(1, len(intersected_complex))
        actual_complex = list(intersected_complex.keys())[0]
        self.assertEqual(expected_complex, actual_complex)
        self.assertEqual(expected_covering, list(intersected_complex.values())[0])

    def test_create_beam(self):
        # Given
        subject = learners.AQAlgorithm(None, None, heuristics.rate_complexes_heuristic, 2)
        AQmetadata = learners.AQMetadata(
            already_used_positive_seeds=[],
            training_data=test_data.discrete_weather_data,
            already_used_examples=[],
            rules_so_far=[],
            numeric_columns=[],
            value_column='play'
        )
        complex1 = models.Complex(
            models.Inclusion('outlook', 'sunny', 'overcast')
        )
        complex2 = models.Complex(
            models.Inclusion('outlook', 'sunny', 'overcast'),
            models.Inclusion('temperature', 'warm')
        )
        complex3 = models.Complex(
            models.Inclusion('outlook', 'sunny', 'overcast'),
            models.Inclusion('wind', 'strong')
        )
        positive_seed_idx = 2
        complexes_covering = {
            complex1: set([0, 1, 2, 6, 7, 8, 10, 11, 12]),
            complex2: set([0, 1, 2, 12]),
            complex3: set([1])
        }
        positive_seed_idx = 2
        expected_beam = {
            complex1: set([0, 1, 2, 6, 7, 8, 10, 11, 12]),
            complex3: set([1])
        }

        # When
        actual_beam = subject.create_beam(complexes_covering, positive_seed_idx, test_data.discrete_weather_data.index, AQmetadata)

        # Then
        self.assertDictEqual(expected_beam, actual_beam)

    def test_building_rules_list_from_cichosz_book(self):
        # Given
        subject = learners.AQAlgorithm(
            heuristics.dissimilarity_based_positive_seed_heuristic_selector,
            heuristics.similarity_based_negative_seed_heuristic_selector,
            heuristics.rate_complexes_heuristic)
        domains = dict()
        for column in test_data.discrete_weather_data.columns:
            if column != 'play':
                domains[column] = set(test_data.discrete_weather_data[column].unique())

        # When
        rules_set = subject.learn_rules(test_data.discrete_weather_data, 'play', domains, dict())

        # Then
        for rule in rules_set.rules:
            print(rule)
            print(check_covering(rule, test_data.discrete_weather_data, 'play'))
            print("----")

    def test_building_rules_list_from_cichosz_book(self):
        # Given
        subject = learners.AQAlgorithm(
            heuristics.dissimilarity_based_positive_seed_heuristic_selector,
            heuristics.similarity_based_negative_seed_heuristic_selector,
            heuristics.rate_complexes_heuristic)
        domains = dict()
        for column in test_data.transport_data.columns:
            if column != 'transportation_mode':
                domains[column] = set(test_data.transport_data[column].unique())

        # When
        rules_set = subject.learn_rules(test_data.transport_data, 'transportation_mode', domains, dict())

        # Then
        for rule in rules_set.rules:
            print(rule)
            print(check_covering(rule, test_data.transport_data, 'transportation_mode'))
            print("----")

def check_covering(rule, training_data, value_column):
    coverings = dict()
    for example_idx in training_data.index:
            example = training_data.loc[example_idx, :]
            example_class = example[value_column]
            if rule.covers_example(example):
                coverings.setdefault(example_class, 0)
                coverings[example_class] += 1
    return coverings

if __name__ == '__main__':
    unittest.main()
