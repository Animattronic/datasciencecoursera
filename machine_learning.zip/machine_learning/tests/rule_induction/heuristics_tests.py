__author__ = 'Filip'

import unittest
import core.rule_induction.models as models
import core.rule_induction.heuristics as heuristics
import tests.rule_induction.test_data as test_data


class HeuristicsTest(unittest.TestCase):
    def setUp(self):
        self.test_data = test_data.discrete_weather_data

    def test_dissimilarity_based_positive_seed_heuristic(self):
        # Given
        heuristic_data = heuristics.HeuristicSearchData(
            training_data=self.test_data[self.test_data['play'] == False],
            already_used_examples=[],
            rules_so_far=[],
            already_used_positive_seeds=[0, 1],
            numeric_columns=[],
            value_column='play'
        )
        expected_positive_seed_idx = 5

        # When
        actual_positive_seed_idx = heuristics.dissimilarity_based_positive_seed_heuristic_selector(
            self.test_data[self.test_data['play'] == False].index,
            heuristic_data)

        # Then
        self.assertEqual(expected_positive_seed_idx, actual_positive_seed_idx)


    def test_similarity_based_negative_seed_heuristic(self):
        # Given
        heuristic_data = heuristics.HeuristicSearchData(
            training_data=self.test_data,
            already_used_examples=[],
            rules_so_far=[],
            already_used_positive_seeds=[],
            numeric_columns=[],
            value_column='play'
        )
        expected_negative_seed_idx = 2
        complex = models.Complex(
            models.Inclusion('humidity', 'high', 'normal'),
            models.Inclusion('outlook', 'sunny', 'overcast', 'rainy'),
            models.Inclusion('warm', models.AllowedValues.AnyAllowed),
            models.Inclusion('wind', models.AllowedValues.AnyAllowed)
        )

        # When
        actual_positive_seed_idx = heuristics.similarity_based_negative_seed_heuristic_selector(
            positive_seed_idx=0,
            heuristic_search_data=heuristic_data
        )

        # Then
        self.assertEqual(expected_negative_seed_idx, actual_positive_seed_idx)


    def test_rate_complex(self):
        # Given
        heuristic_data = heuristics.HeuristicSearchData(
            training_data=self.test_data,
            already_used_examples=[],
            rules_so_far=[],
            already_used_positive_seeds=[],
            numeric_columns=[],
            value_column='play'
        )
        complex1 = models.Complex(
            models.Inclusion('outlook', 'sunny', 'overcast')
        )
        complex2 = models.Complex(
            models.Inclusion('outlook', 'sunny', 'overcast'),
            models.Inclusion('temperature', 'warm')
        )
        complex3 = models.Complex(
            models.Inclusion('outlook', 'sunny', 'overcast'),
            models.Inclusion('wind', 'strong')
        )
        positive_seed_idx = 2
        expected_rated_complexes = [complex1, complex3, complex2]

        # When
        rated_complexes = heuristics.rate_complexes_heuristic(
            complexes=[complex1, complex2, complex3],
            positive_seed_idx=positive_seed_idx,
            example_indices=self.test_data.index,
            heuristic_search_data=heuristic_data)

        # Then
        self.assertSequenceEqual(expected_rated_complexes, rated_complexes)



if __name__ == '__main__':
    unittest.main()
