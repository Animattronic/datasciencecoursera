__author__ = 'Filip'

import pandas as pd

discrete_weather_data = pd.DataFrame({
    'outlook': [
        'sunny',
        'sunny',
        'overcast',
        'rainy',
        'rainy',
        'rainy',
        'overcast',
        'sunny',
        'sunny',
        'rainy',
        'sunny',
        'overcast',
        'overcast',
        'rainy'
    ],
    'temperature': [
        'warm',
        'warm',
        'warm',
        'moderate',
        'cold',
        'cold',
        'cold',
        'moderate',
        'cold',
        'moderate',
        'moderate',
        'moderate',
        'warm',
        'moderate'
    ],
    'humidity': [
        'high',
        'high',
        'high',
        'high',
        'normal',
        'normal',
        'normal',
        'high',
        'normal',
        'normal',
        'normal',
        'high',
        'normal',
        'high'
    ],
    'wind': [
        'mild',
        'strong',
        'mild',
        'mild',
        'mild',
        'strong',
        'strong',
        'mild',
        'mild',
        'mild',
        'strong',
        'strong',
        'mild',
        'strong'
    ],
    'play': [
        False,
        False,
        True,
        True,
        True,
        False,
        True,
        False,
        True,
        True,
        True,
        True,
        True,
        False
    ]
})


transport_data = pd.DataFrame({
                'gender': ['male', 'male', 'female', 'female', 'male', 'male', 'female', 'female', 'male', 'female'],
                'car_ownership': ['0', '1', '1', '0', '1', '0', '1', '1', '2', '2'],
                'travel_cost': ['cheap', 'cheap', 'cheap', 'cheap', 'cheap', 'standard', 'standard', 'expensive', 'expensive', 'expensive'],
                'income_level': ['low', 'medium', 'medium', 'low', 'medium', 'medium', 'medium', 'high', 'medium', 'high'],
                'transportation_mode': ['bus', 'bus', 'train', 'bus', 'bus', 'train', 'train', 'car', 'car', 'car']
            })