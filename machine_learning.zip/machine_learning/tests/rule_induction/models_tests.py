__author__ = 'Filip'

import unittest
import core.rule_induction.models as models
import operator as opr


class TestSelectors(unittest.TestCase):

    def test_complex_is_empty(self):
        # Given
        complex = models.Complex(models.Selector('some', models.AllowedValues.NoneAllowed))

        # Then
        self.assertTrue(complex.is_empty())

    def intersect_complexes(self):
        # Given
        complex1 = models.Complex(models.Selector('outlook', 'sunny', 'overcast'))
        complex2 = models.Complex(models.Selector('outlook', 'sunny'), models.Selector('wind', 'strong'))
        complex3 = models.Complex(models.Selector('outlook', 'sunny'), models.Selector('temperature', 'warm'), models.Selector('wind', 'strong'))
        complex4 = models.Complex(models.Selector('temperature', 'warm', 'moderate'))

        expected_complex13 = models.Complex(models.Selector('outlook', 'sunny'), models.Selector('temperature', 'warm'), models.Selector('wind', 'strong'))
        expected_complex14 = models.Complex(models.Selector('outlook', 'sunny', 'overcast'), models.Selector('temperature', 'warm', 'moderate'))
        expected_complex24 = models.Complex(models.Selector('outlook', 'sunny'), models.Selector('wind', 'strong'), models.Selector('temperature', 'warm', 'moderate'))

        # When
        actual_complex13 = complex1.intersect(complex3)
        actual_complex14 = complex1.intersect(complex4)
        actual_complex24 = complex1.intersect(complex4)

        # Then
        self.assertEquals(expected_complex13, actual_complex13)
        self.assertEquals(expected_complex14, actual_complex14)
        self.assertEquals(expected_complex24, actual_complex24)



    def test_range_result_true_start_end_open(self):
        # Given
        subject = models.Range('val', 2, 4, opr.__gt__, opr.__lt__)
        example = {'val': 3}

        # When
        result = subject.covers_example(example)

        # Then
        self.assertTrue(result)

    def test_range_result_false_start_end_open(self):
        # Given
        subject = models.Range('val', 2, 4, opr.__gt__, opr.__lt__)
        example = {'val': 4}

        # When
        result = subject.covers_example(example)

        # Then
        self.assertFalse(result)

    def test_range_result_true_start_open(self):
        # Given
        subject = models.Range('val', 2, 4, opr.__gt__, opr.__le__)
        example = {'val': 3}

        # When
        result = subject.covers_example(example)

        # Then
        self.assertTrue(result)

    def test_range_result_true_start_open(self):
        # Given
        subject = models.Range('val', 2, 4, opr.__gt__, opr.__le__)
        example = {'val': 4}

        # When
        result = subject.covers_example(example)

        # Then
        self.assertTrue(result)

    def test_range_result_true_end_open(self):
        # Given
        subject = models.Range('val', 2, 4, opr.__ge__, opr.__lt__)
        example = {'val': 2}

        # When
        result = subject.covers_example(example)

        # Then
        self.assertTrue(result)

    def test_range_result_false_end_open(self):
        # Given
        subject = models.Range('val', 2, 4, opr.__ge__, opr.__lt__)
        example = {'val': 4}

        # When
        result = subject.covers_example(example)

        # Then
        self.assertFalse(result)

    def test_inclusion_intersect(self):
        # Given
        inclusion1 = models.Inclusion('val', 'a', 'b', 'c')
        inclusion2 = models.Inclusion('val', 'c', 'd', 'e')

        expected_inclusion = models.Inclusion('val', 'c')

        # When
        actual_inclusion = inclusion1.intersect(inclusion2)

        # Then
        self.assertEquals(actual_inclusion, expected_inclusion)

    def test_inclusion_intersect_all_values_allowed(self):
        # Given
        inclusion1 = models.Inclusion('val', models.AllowedValues.AnyAllowed)
        inclusion2 = models.Inclusion('val', 'c', 'd', 'e')

        expected_inclusion = models.Inclusion('val', 'c', 'd', 'e')

        # When
        actual_inclusion = inclusion1.intersect(inclusion2)

        # Then
        self.assertEquals(actual_inclusion, expected_inclusion)

    def test_inclusion_intersect_none_allowed(self):
        # Given
        inclusion1 = models.Inclusion('val', models.AllowedValues.NoneAllowed)
        inclusion2 = models.Inclusion('val', 'c', 'd', 'e')

        expected_inclusion = models.Inclusion('val', models.AllowedValues.NoneAllowed)

        # When
        actual_inclusion = inclusion1.intersect(inclusion2)

        # Then
        self.assertEquals(actual_inclusion, expected_inclusion)

    def test_intersection_lesser_lesser_1(self):
        # Given
        selector1 = models.NumericSelector('a', 10, opr.__lt__)
        selector2 = models.NumericSelector('a', 5, opr.__lt__)

        expected = models.NumericSelector('a', 5, opr.__lt__)

        # When
        actual = selector1.intersect(selector2)

        # Then
        self.assertEqual(expected, actual)

    def test_intersection_lesser_lesser_than_1(self):
        # Given
        selector1 = models.NumericSelector('a', 10, opr.__lt__)
        selector2 = models.NumericSelector('a', 5, opr.__le__)

        expected = models.NumericSelector('a', 5, opr.__le__)

        # When
        actual = selector1.intersect(selector2)

        # Then
        self.assertEqual(expected, actual)


    def test_intersection_lesser_lesser_than_2(self):
        # Given
        selector1 = models.NumericSelector('a', 10, opr.__le__)
        selector2 = models.NumericSelector('a', 5, opr.__lt__)

        expected = models.NumericSelector('a', 5, opr.__lt__)

        # When
        actual = selector1.intersect(selector2)

        # Then
        self.assertEqual(expected, actual)

    def test_intersection_lesser_greater_proper_overlap(self):
        # Given
        selector1 = models.NumericSelector('a', 10, opr.__le__)
        selector2 = models.NumericSelector('a', 5, opr.__ge__)

        expected = models.Range('a', 5, 10, opr.__ge__, opr.__le__)

        # When
        actual = selector1.intersect(selector2)

        # Then
        self.assertEqual(expected, actual)

    def test_intersection_lesser_greater_invalid_overlap(self):
        # Given
        selector1 = models.NumericSelector('a', 5, opr.__le__)
        selector2 = models.NumericSelector('a', 10, opr.__ge__)

        expected = models.Inclusion('a', models.AllowedValues.NoneAllowed)

        # When
        actual = selector1.intersect(selector2)

        # Then
        self.assertEqual(expected, actual)

    def test_intersection_lesser_then_with_range_1(self):
        # Given
        selector1 = models.NumericSelector('a', 5, opr.__le__)
        selector2 = models.Range('a', 1, 10, opr.__gt__, opr.__lt__)

        expected = models.Range('a', 1, 5, opr.__gt__, opr.__le__)

        # When
        actual = selector1.intersect(selector2)

        # Then
        self.assertEqual(expected, actual)

    def test_intersection_lesser_then_with_range_2(self):
        # Given
        selector1 = models.NumericSelector('a', 5, opr.__ge__)
        selector2 = models.Range('a', 1, 10, opr.__gt__, opr.__lt__)

        expected = models.Range('a', 5, 10, opr.__ge__, opr.__lt__)

        # When
        actual = selector1.intersect(selector2)

        # Then
        self.assertEqual(expected, actual)

    def test_intersection_lesser_then_with_range_3(self):
        # Given
        selector1 = models.NumericSelector('a',  12, opr.__le__)
        selector2 = models.Range('a', 1, 10, opr.__gt__, opr.__lt__)

        expected = models.Range('a', 1, 10, opr.__gt__, opr.__lt__)

        # When
        actual = selector1.intersect(selector2)

        # Then
        self.assertEqual(expected, actual)

    def test_range_intersection_1(self):
        # Given
        range1 = models.Range('a', 5, 10, opr.__gt__, opr.__lt__)
        range2 = models.Range('a', 1, 6, opr.__ge__, opr.__le__ )
        expected_result = models.Range('a', 5, 6, opr.__gt__, opr.__le__)

        # When
        actual_result = range1.intersect(range2)

        # Then
        self.assertEqual(actual_result, expected_result)

    def test_range_intersection(self):
        # Given
        range1 = models.Range('a', 5, 10, opr.__gt__, opr.__lt__)
        range2 = models.Range('a', 6, 9, opr.__ge__, opr.__le__ )
        expected_result = range2

        # When
        actual_result = range1.intersect(range2)

        # Then
        self.assertEqual(actual_result, expected_result)



if __name__ == '__main__':
    unittest.main()
