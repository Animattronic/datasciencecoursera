__author__ = 'Filip'

import unittest
import core.first_order_logic.models as models
import core.first_order_logic.operators as operators

class FirstOrderLogicTester(unittest.TestCase):

    def test_negate_atom(self):
        # Given
        atom = models.AtomSentence("atom1", 2)
        expected_atom = models.ComplexSentence(
            name="not atom1",
            arity=2,
            logic_operator=operators.Pass(),
            subsentences_names=[models.SentenceName(atom.name, negated=True)],
            subsentences_mappings={
                0: [0, 1]
            })

        # When
        actual_atom = atom.negate()

        # Then
        self.assertEqual(expected_atom, actual_atom)

    def test_complex_sentence(self):
        # Given
        complex_sentence = models.ComplexSentence(
            name="sentence1",
            logic_operator=operators.And(),
            arity=2,
            subsentences_names=[models.SentenceName("ss1"), models.SentenceName("ss2"), models.SentenceName("ss3")],
            subsentences_mappings={
                0:[0, -1],
                1:[-1,0],
                2:[1,0]
            })

        expected_ss2_mappings = [-1, 0]

        # When
        actual_ss2_mappings = complex_sentence.mappings_for_subsentence(1)

        # Then
        self.assertEqual(expected_ss2_mappings, actual_ss2_mappings)




if __name__ == '__main__':
    unittest.main()
