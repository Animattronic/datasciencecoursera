__author__ = 'Filip'

import unittest
import core.first_order_logic.models as models
import core.first_order_logic.evaluators as evaluators
import core.first_order_logic.operators as operators


class EvaluatorsTests(unittest.TestCase):

    def setUp(self):
        self.dispatcher = evaluators.VariablesDispatcher()

    def test_dispatching_variables(self):
        # Given
        complex_sentence = models.ComplexSentence(
            name="sentence1",
            logic_operator=operators.And(),
            arity=2,
            subsentences_names=[models.SentenceName("ss1"), models.SentenceName("ss2"), models.SentenceName("ss3")],
            subsentences_mappings={
                0:[0, -1],
                1:[-1,0],
                2:[1,0]
            })

        variables = ["x", "y"]
        expected_dispatched_variables = {
            0: ["x", "sentence1_implicit_1_0.5714025946899135"],
            1: ["sentence1_implicit_1_0.5714025946899135", "x"],
            2: ["y", "x"]
        }

        # When
        actual_dispatched_variables = self.dispatcher.dispatch_variables(complex_sentence, variables)

        # Then
        self.assertDictEqual(expected_dispatched_variables, actual_dispatched_variables)

    def test_atom_evaluation_no_temp_substitutions(self):
        # Given
        knowledge_base = models.KnowledgeBase()
        atom1 = models.AtomSentence("knows", 2)
        knowledge_base.add_atom(atom1, ['a', 'b'], ['b', 'c'])

        knowledge_base.set_variable_value('x', 'b')
        knowledge_base.set_variable_value('y', 'c')

        subject = evaluators.Evaluator(knowledge_base, self.dispatcher)

        # When
        result = subject.evaluate(atom1, ['x', 'y'])

        # Then
        self.assertTrue(result)

    def test_atom_evaluation_missing_one_substitution(self):
        # Given
        knowledge_base = models.KnowledgeBase()
        atom1 = models.AtomSentence("knows", 2)
        knowledge_base.add_atom(atom1, ['a', 'b'], ['b', 'c'])

        knowledge_base.set_variable_value('y', 'c')
        subject = evaluators.Evaluator(knowledge_base, self.dispatcher)

        expected_substitution = models.VariableSubstitution('x', 'b')
        # When
        result = list(subject.find_solutions(atom1, ['x', 'y']))

        # Then
        self.assertEquals(1, len(result))
        self.assertEquals(1, len(result[0]))
        self.assertEquals(expected_substitution, result[0][0])

    def test_complex_sentence_evaluation_all_variables_are_substituted(self):
        #Given
        knows = models.AtomSentence("knows", 2)
        complex_sentence = models.ComplexSentence(
            name="knows by someone",
            arity=3,
            logic_operator=operators.And(),
            subsentences_mappings={
                0: [0, 1],
                1: [1, 2]
            },
            subsentences_names=[models.SentenceName("knows"), models.SentenceName("knows")])
        variables = ['x', 'y', 'z']

        knowledge_base = models.KnowledgeBase()
        knowledge_base.add_atom(knows, ["a", "b"], ["b", "c"])
        knowledge_base.add_complex_sentence(complex_sentence)
        knowledge_base.set_variable_value('x', 'a')
        knowledge_base.set_variable_value('y', 'b')
        knowledge_base.set_variable_value('z', 'c')

        subject = evaluators.Evaluator(knowledge_base, self.dispatcher)

        #When
        result = subject.evaluate(complex_sentence, variables)

        #Then
        self.assertTrue(result)

    def test_find_possible_values_for_complex_sentence_with_implicit_variables(self):
        # Given
        partOf = models.AtomSentence("part of", 2)
        complex_sentence = models.ComplexSentence(
            name="part of",
            arity=2,
            logic_operator=operators.And(),
            subsentences_mappings={
                0: [0, -1],
                1: [-1, 1]
            },
            subsentences_names=[models.SentenceName("part of"), models.SentenceName("part of")])
        variables = ['x', 'y']

        knowledge_base = models.KnowledgeBase()
        knowledge_base.add_atom(partOf, ["poland", "europe"], ["europe", "earth"])
        knowledge_base.add_complex_sentence(complex_sentence)
        knowledge_base.set_variable_value('x', 'poland')

        subject = evaluators.Evaluator(knowledge_base, self.dispatcher)
        actual_possible_values = dict()
        expected_possible_values = {
            'y': ['europe', 'earth'],
            'part of_implicit_1_0.5714025946899135': ['europe', 'earth', 'poland', 'europe']
        }

        # When
        subject.find_possible_values(complex_sentence, variables, actual_possible_values)

        # Then
        self.assertEquals(expected_possible_values, actual_possible_values)


if __name__ == '__main__':
    unittest.main()