__author__ = 'Filip'

import pandas as pd
import numpy as np


class Bagger():

    def __init__(self, model_builder, bag_size=1000):
        self.__bag_size = bag_size
        self.__model_builder = model_builder

    def build_model(self, data, value_column):
        sub_models = []
        for i in range(self.__bag_size):
            selected_data_indices = np.random.choice(data.index, len(data), replace=True)
            sub_models.append(self.__model_builder.build_model(data.loc[selected_data_indices], value_column))
        return sub_models


class BaggingPredictor():

    def __init__(self, bagging_tree_model, decision_value, decision_tree_predictor_factory):
        self.__bagging_tree_model = bagging_tree_model
        self.__decision_value = decision_value
        self.__decision_tree_predictor_factory = decision_tree_predictor_factory

    def predict(self, queries):
        results = None
        for sub_tree in self.__bagging_tree_model:
            predictor = self.__decision_tree_predictor_factory(sub_tree, self.__decision_value)
            partial_results = predictor.predict(queries)
            if results is None:
                results = np.array(partial_results).reshape((1, len(partial_results)))
            else:
                results = np.vstack((partial_results, results))

        final_results = []
        for col_idx in range(results.shape[1]):
            column = results[:, col_idx]
            final_results.append(pd.value_counts(column, sort=True).index[0])
        return final_results