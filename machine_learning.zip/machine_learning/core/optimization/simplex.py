__author__ = 'Filip'

import numpy as np
import scipy as sp

class SimplexOptimizer():

    def __init__(self, expansion_rate = 2.0, auto_update_step = 0.01):
        self.__expansion_rate = expansion_rate
        self.__auto_update_step = auto_update_step


    def solve(self, evaluator, problem_domains, iterations, stop_threshold = 0.01):
        domain_size = len(problem_domains)
        solutions = self.generate_initial_solutions(problem_domains)
        for i in range(iterations):
            graded_solutions = { i: evaluator.evaluate(solutions[i]) for i in range(len(solutions)) }
            ordered_solutions = sorted(graded_solutions, key=graded_solutions.get)
            best, middle, worst = [solutions[i] for i in ordered_solutions]
            centroid = [ (best[i] + middle[i]/2) for i in range(domain_size) ]






    def generate_initial_solutions(self, problem_domains):
        return  [
                    [np.random.uniform(domain[0], domain[1])
                        for domain in problem_domains]
                    for i in range(3)
                ]

optimizer = SimplexOptimizer()
print(optimizer.generate_initial_solutions([(5, 10), (100, 200), (300, 500)]))