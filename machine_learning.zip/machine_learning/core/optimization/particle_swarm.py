__author__ = 'Filip'

import numpy as np
import math
import random
from copy import deepcopy

class Particle():

    def __init__(self, position, velocity, error = 0, ):
        self.position = position
        self.velocity = velocity
        self.__best_position = position
        self.__lowest_error = error
        self.__current_error = error

    @property
    def current_error(self):
        return self.__current_error

    @current_error.setter
    def current_error(self, value):
        if value < self.__lowest_error:
            self.__lowest_error = value
            self.__best_position = deepcopy(self.position)
        self.__current_error = value

    @property
    def lowest_error(self):
        return self.__lowest_error

    @property
    def best_position(self):
        return self.__best_position

class ParticleSwarm():

    def __init__(self, particles_count, intertia = 0.729, cognitive_weight = 1.49445, social_weight = 1.49445):
        self.cognitive_weight = cognitive_weight
        self.social_weight = social_weight
        self.intertia = intertia
        self.particles_count = particles_count

    def solve_problem(self, problem_domains, cost_function, iterations):
        particles, lowest_known_error, best_global_position = self.initialize_random_particles(problem_domains, cost_function)
        errors = []
        for i in range(iterations):
            print("Iteration: " + str(i))
            print("Lowest error so far: " + str(lowest_known_error))
            particle_indices = list(range(0, len(particles)))
            random.shuffle(particle_indices)
            for particle_index in particle_indices:
                particle = particles[particle_index]
                self.update_particle_position(particle, problem_domains, lowest_known_error, best_global_position, cost_function)
                if particle.current_error < lowest_known_error:
                    lowest_known_error = particle.current_error
                    best_global_position = deepcopy(particle.position)
                errors.append(particle.current_error)
        return best_global_position

    def build_random_vector(self, problem_domain):
        return [np.random.uniform(domain[0], domain[1]) for domain in problem_domain]

    def initialize_random_particles(self, problem_domain, error_function):
        best_known_position = [0] * len(problem_domain)
        lowest_known_error = float('inf')
        particles = []
        for particle_num in range(self.particles_count):
            particle_position = self.build_random_vector(problem_domain)
            particle_velocity = self.build_random_vector(problem_domain)
            error = error_function(particle_position)
            particle = Particle(particle_position, particle_velocity, error)
            particles.append(particle)
            if error < lowest_known_error:
                lowest_known_error = error
                best_known_position = particle_position
        return particles, lowest_known_error, best_known_position

    def update_particle_position(self, particle, problem_domain, lowest_known_error, global_best_position, error_function):
        new_position = []
        new_velocity = []
        for feature_index in range(len(problem_domain)):
            min, max = problem_domain[feature_index]
            updated_velocity = (particle.velocity[feature_index] * self.intertia) + \
                (np.random.uniform(0, 1) * self.cognitive_weight * (particle.best_position[feature_index] - particle.position[feature_index])) + \
                (np.random.uniform(0, 1) * self.social_weight * (global_best_position[feature_index] - particle.position[feature_index]))
            updated_position = particle.position[feature_index] + updated_velocity
            new_position.append(updated_position)
            new_velocity.append(updated_velocity)

        for i in range(len(problem_domain)):
            axis_position = new_position[i]
            axis_domain = problem_domain[i]
            if axis_position < axis_domain[0]:
                new_position[i] = axis_domain[0]
            if axis_position > axis_domain[1]:
                new_position[i] = axis_domain[1]
        particle.position = new_position
        particle.velocity = new_velocity
        particle.current_error = error_function(new_position)
