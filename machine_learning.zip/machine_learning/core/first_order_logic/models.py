__author__ = 'Filip'

from copy import deepcopy
import core.first_order_logic.operators as operators

class VariableSubstitution():

    def __init__(self, variable_name, variable_value):
        self.__variable_name = variable_name
        self.__variable_value = variable_value

    @property
    def variable_name(self):
        return self.__variable_name

    @property
    def variable_value(self):
        return self.__variable_value

    def __eq__(self, other):
        if not(isinstance(other, VariableSubstitution)):
            return False
        return self.variable_name == other.variable_name and self.variable_value == other.variable_value


class SentenceName():

    def __init__(self, sentence_name, negated=False):
        self.__sentence_name = sentence_name
        self.__negated = negated

    @property
    def sentence_name(self):
        return self.__sentence_name

    @property
    def negated(self):
        return self.__negated

    def negate(self):
        return SentenceName(self.sentence_name, not self.negated)

    def __eq__(self, other):
        if not isinstance(other, SentenceName):
            return False
        return self.sentence_name == other.sentence_name and self.negated == other.negated

    def __hash__(self):
        return hash(self.sentence_name) + hash(self.negated)


class Sentence():

    def __init__(self, name, arity):
        self.__name = name
        self.__arity = arity

    @property
    def name(self):
        return self.__name

    @property
    def arity(self):
        return self.__arity

    def negate(self):
        raise NotImplementedError()


class AtomSentence(Sentence):

    def __init__(self, name, arity):
        super().__init__(name, arity)

    def negate(self):
        new_name = str.format("not {0}", self.name)
        return ComplexSentence(
            name=new_name,
            arity=self.arity,
            logic_operator=operators.Pass(),
            subsentences_names=[SentenceName(self.name, negated=True)],
            subsentences_mappings={
                0: list(range(0, self.arity))
            })

    def __eq__(self, other):
        if not isinstance(other, AtomSentence):
            return False
        return self.name == other.name and self.arity == other.arity

    def __hash__(self):
        return hash(hash(self.arity) + hash(self.name))


class ComplexSentence(Sentence):

    def __init__(self, name, arity, logic_operator, subsentences_names, subsentences_mappings):
        super().__init__(name, arity)
        self.__subsentences_names = subsentences_names
        self.__implicit_variables = dict()
        self.__subsentences_mappings = dict()
        self.__logic_operator = logic_operator
        self.__build_subsentences_mappings(subsentences_mappings)

    @property
    def logic_operator(self):
        return self.__logic_operator

    @property
    def subsentences_names(self):
        return deepcopy(self.__subsentences_names)

    @property
    def subsentences_mappings(self):
        return deepcopy(self.__subsentences_mappings)

    @property
    def implicit_variables(self):
        return deepcopy(self.__implicit_variables)

    def mappings_for_subsentence(self, subsentence_index):
        if subsentence_index < 0 or subsentence_index > self.arity:
            raise IndexError("Subsentence index out of bounds")
        return self.__subsentences_mappings[subsentence_index]

    def get_implicit_variable(self, index):
        if index >= 0:
            raise AttributeError("Invalid index for implicit variable!")
        return self.implicit_variables[index]

    def __build_subsentences_mappings(self, subsentences_mappings):
        for subsentence_index, variables_indices in subsentences_mappings.items():
            mappings = []
            for index in variables_indices:
                if index < 0:
                    if not(index in self.__implicit_variables):
                        self.__implicit_variables[index] = self.__build_implicit_variable_name(index)
                mappings.append(index)
            self.__subsentences_mappings[subsentence_index] = mappings

    def __build_implicit_variable_name(self, index):
        return str.format("{0}_implicit_{1}", self.name, -index)

    def __eq__(self, other):
        if not isinstance(other, ComplexSentence):
            return False
        if self.name != other.name or self.arity != other.arity or self.logic_operator != other.logic_operator:
            return False

        if len(self.subsentences_names) != len(other.subsentences_names):
            return False

        if not(any([
            subsentence in other.subsentences_names
            for subsentence in self.subsentences_names
        ])):
            return False

        if self.implicit_variables != other.implicit_variables:
            return False

        return self.subsentences_mappings == other.subsentences_mappings

    def __hash__(self):
        hash_code = hash(self.name) + hash(self.arity) + hash(frozenset(self.subsentences_names)) + \
            hash(frozenset(self.implicit_variables))
        for subsentence_idx, variables_indices in self.subsentences_mappings.items():
            hash_code += hash(subsentence_idx)
            hash_code += hash(frozenset(variables_indices))
        return hash_code


class KnowledgeBase():

    def __init__(self):
        self.sentences_names = set()
        self.atomic_sentences = dict()
        self.complex_sentences = set()
        self.variables_values = dict()

    def set_variable_value(self, variable, value):
        self.variables_values[variable] = value

    def get_variable_value(self, variable):
        self.variables_values.setdefault(variable, None)
        return self.variables_values[variable]

    def variable_is_set(self, variable):
        return variable in self.variables_values and not(self.variables_values[variable] is None)

    def add_atom(self, atom, *allowed_values):
        if not atom in self.atomic_sentences:
            self.atomic_sentences[atom] = []
        if allowed_values:
            for allowed_values_set in allowed_values:
                self.atomic_sentences[atom].append(allowed_values_set)
        self.sentences_names.add(atom.name)

    def add_complex_sentence(self, complex_sentence):
        if not complex_sentence in self.complex_sentences:
            self.complex_sentences.add(complex_sentence)
        self.sentences_names.add(complex_sentence.name)

    def allowed_values_for_atom(self, atom):
        if not(atom in self.atomic_sentences):
            raise AttributeError("Unknown atom!")
        return self.atomic_sentences[atom]

    def get_atom_by_name(self, atom_name):
        for atom in self.atomic_sentences:
            if atom.name == atom_name:
                return atom
        return None

    def get_complex_sentences_by_name(self, complex_sentence_name):
        for complex_sentence in self.complex_sentences:
            if complex_sentence.name == complex_sentence_name:
                yield complex_sentence