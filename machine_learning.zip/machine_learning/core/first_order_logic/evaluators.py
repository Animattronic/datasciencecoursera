__author__ = 'Filip'

import core.first_order_logic.models as models
import core.first_order_logic.operators as operators
import random as rnd

class ParamMapping():

    def __init__(self, position, variable_name):
        self.__position = position
        self.__variable_name = variable_name

    @property
    def position(self):
        return self.__position

    @property
    def variable_name(self):
        return self.__variable_name


class VariablesDispatcher():

    def __init__(self, randomizer = rnd.Random(10)):
        self.__randomizer = randomizer

    def dispatch_variables(self, complex_sentence, variables):
        """
        @type complex_sentence: core.first_order_logic.models.ComplexSentence
        @type variables: list
        """
        if len(variables) != complex_sentence.arity:
            raise AttributeError("Too many variables to dispatch for this complex sentence!")
        dispatched_variables = dict()
        encountered_implicit_variables = dict()
        for subsentence_idx, variables_indices in complex_sentence.subsentences_mappings.items():
            dispatched_variables[subsentence_idx] = []
            for variable_idx in variables_indices:
                if variable_idx >= 0:
                    dispatched_variables[subsentence_idx].append(variables[variable_idx])
                else:
                    implicit_variable_name = complex_sentence.get_implicit_variable(variable_idx)
                    if not(implicit_variable_name in encountered_implicit_variables):
                        encountered_implicit_variables.setdefault(implicit_variable_name)
                        encountered_implicit_variables[implicit_variable_name] = str.format("{0}_{1}", implicit_variable_name, self.__randomizer.random())
                    dispatched_variables[subsentence_idx].append(encountered_implicit_variables[implicit_variable_name])
        return dispatched_variables


class Evaluator():
    #TODO: implement all elements from the list!!!
    """
    Target:
    1) Evaluating atoms:
        a) variables are set [DONE]
        b) variables are not set [DONE]
    2) Evaluating complex sentences:
        a) variables are set + implicit variables substitution [DONE]
        b) variables are not set + implicit variables substitution [TODO]
    3) Evaluating recursive sentences
    """

    def __init__(self, knowledge_base, dispatcher):
        """
        @type knowledge_base: core.first_order_logic.models.KnowledgeBase
        @type dispatcher: core.first_order_logic.evaluators.VariablesDispatcher
        """
        self.__knowledge_base = knowledge_base
        self.__dispatcher = dispatcher

    def evaluate(self, sentence, variables, temp_substitutions=None):
        if isinstance(sentence, models.AtomSentence):
            return self.evaluate_atom(sentence, variables, temp_substitutions)
        else:
            return self.evaluate_complex_sentence(sentence, variables)

    def evaluate_complex_sentence(self, sentence, variables, temp_substitutions=None):
        """
        Evaluates complex sentence against passed variables
        @type sentence: core.first_order_logic.models.ComplexSentence
        @type variables: list
        @type temp_substitutions: dict
        """
        dispatched_variables = self.__dispatcher.dispatch_variables(sentence, variables)
        sub_evaluation_results = []
        for subsentence_idx, sentence_variables in dispatched_variables.items():
            if not(self.all_variables_are_set(sentence_variables, temp_substitutions)):
                atom_sentence = self.__knowledge_base.get_atom_by_name(subsentence_name.sentence_name)
                """
                TODO: handle finding possible values for atom. Consider using it further, when execution proceeds to other
                subsentences. Substitution made during every iteration must be persisted for all execution paths. Possible solutions:
                1) gather all possible values for all missing variables in all subsentences. And later on try to match them
                2) use recursive executions of the solving procedure (how exactly do this???)
                """
                raise NotImplementedError()
            else:
                subsentence_name = sentence.subsentences_names[subsentence_idx]
                atoms_evaluation_succeeded = False
                atom_sentence = self.__knowledge_base.get_atom_by_name(subsentence_name.sentence_name)
                if atom_sentence.arity == len(sentence_variables):
                    result = self.evaluate_atom(atom_sentence, sentence_variables, temp_substitutions)
                    if result:
                        result = result if (not subsentence_name.negated) else not result
                        sub_evaluation_results.append(result)
                        atoms_evaluation_succeeded = True
                if not atoms_evaluation_succeeded:
                    #TODO: implement complex sentences searching
                    raise NotImplementedError()
        return sentence.logic_operator.evaluate(sub_evaluation_results)

    def evaluate_atom(self, atom, variables, temp_substitutions=None):
        """
        Performs evaluation of atom. If variables are not set throws exception.
        @type atom: core.first_order_logic.models.AtomSentence
        @type variables: list
        @type temp_substitutions: dict
        """
        if atom.arity != len(variables):
            self.__raise_invalid_number_of_values_passed_for_atom_evaluation(atom.arity, len(variables))
        if not(self.all_variables_are_set(variables, temp_substitutions)):
                self.__raise_variables_are_not_set()

        allowed_values_for_atom = self.__knowledge_base.allowed_values_for_atom(atom)
        current_variables_values = []
        for variable_name in variables:
            if self.__knowledge_base.variable_is_set(variable_name):
                current_variables_values.append(self.__knowledge_base.get_variable_value(variable_name))
            else:
                current_variables_values.append(temp_substitutions[variable_name])
        return any([current_variables_values == allowed_values_set for allowed_values_set in allowed_values_for_atom])

    def find_solutions(self, sentence, variables):
        if isinstance(sentence, models.AtomSentence):
            if self.all_variables_are_set(variables):
                return [
                    models.VariableSubstitution(variable, self.__knowledge_base.get_variable_value(variable))
                    for variable in variables
                ]
            else:
                unset_indices = [
                    idx
                    for idx, variable in enumerate(variables)
                    if not(self.__knowledge_base.variable_is_set(variable))
                ]
                return self.find_solutions_for_atom(sentence, variables, unset_indices)
        else:
            #TODO: implement it for the complex sentences
            raise NotImplementedError()

    def find_solutions_for_atom(self, atom, variables, unset_indices):
        """
        Searches for the solutions for atom if not all variables are set. Yields subsequent substitutions that
        can guarantee positive evaluation.
        @type atom: core.first_order_logic.models.AtomSentence
        @type variables: list
        @type unset_indices: list
        """
        possible_values = dict()
        self.find_possible_values(atom, variables, possible_values)
        for solution in self.substitute_variables_and_try_evaluate(atom, variables, unset_indices, possible_values, dict()):
            yield solution

    def find_solutions_for_complex_sentence(self, complex_sentence, variables, temp_substitutions=dict()):
        dispatched_variables = self.__dispatcher.dispatch_variables(complex_sentence, variables)
        unset_variables = {variable for variables_set in dispatched_variables.values() for variable in variables_set
            if not(self.__knowledge_base.variable_is_set(variable) or variable in temp_substitutions)
        }
        #TODO: consider setting mapped positions here, on this level of nesting!!!
        possible_values = dict()
        mapped_positions = dict()
        if any(unset_variables):
            for subsentence_idx, subsentence_variables in dispatched_variables:
                unset_variables_for_sentence = set(subsentence_variables) & unset_variables
                if unset_variables_for_sentence:
                    subsentence_name = sentence.subsentences_names[subsentence_idx]
                    atom_subsentence = self.__knowledge_base.get_atom_by_name(subsentence_name.sentence_name)
                    if atom_subsentence:
                        self.find_possible_values_in_recursive_tree(atom_subsentence, subsentence_variables, unset_variables_for_sentence, mapped_positions, possible_values)
                    complex_sentence = self.__knowledge_base.get_complex_sentences_by_name(subsentence_name.sentence_name)
                    if complex_sentence:
                        self.find_possible_values_in_recursive_tree(atom_subsentence, subsentence_variables, unset_variables_for_sentence, mapped_positions, possible_values)
        new_temp_substitutions = dict(temp_substitutions)
        #TODO: non-recursive algorithm for substituting variables needed here!!!



    def substitute_variables_and_try_evaluate(
            self,
            sentence,
            variables,
            unset_indices,
            possible_values,
            substitutions):
        if len(unset_indices) == 0:
            if self.evaluate(sentence, variables, substitutions):
                yield [
                    models.VariableSubstitution(variable_name, variable_value)
                    for variable_name, variable_value in substitutions.items()]
        else:
            #TODO: add heuristic for 'smart' finding next substitutions!!!
            current_idx, tail = unset_indices[0], unset_indices[1:]
            current_variable = variables[current_idx]
            for possible_value in possible_values[current_variable]:
                new_substitutions = dict(substitutions)
                new_substitutions[current_variable] = possible_value
                for solution in self.substitute_variables_and_try_evaluate(sentence, variables, tail, possible_values, new_substitutions):
                    yield solution

    def find_possible_values(self, sentence, variables, possible_values):
        if isinstance(sentence, models.AtomSentence):
            if not(self.all_variables_are_set(variables)):
                unset_indices = self.find_unset_variables_indices(variables)
                self.find_possible_values_for_atom(sentence, unset_indices, variables, possible_values)
        else:
            dispatched_variables = self.__dispatcher.dispatch_variables(sentence, variables)
            target_variables = set()
            mapped_positions = dict()
            for variable_set in dispatched_variables.values():
                for variable in variable_set:
                    if not(self.__knowledge_base.variable_is_set(variable)):
                        target_variables.add(variable)
                        mapped_positions.setdefault(variable, dict())
            for subsentence_idx, sentence_variables in dispatched_variables.items():
                subsentence_name = sentence.subsentences_names[subsentence_idx]
                #TODO: think about using looping through the complex sentences too but to AVOID INFINITE LOOPS!!!
                if not(self.all_variables_are_set(sentence_variables)):
                    atom_subsentence = self.__knowledge_base.get_atom_by_name(subsentence_name.sentence_name)
                    if atom_subsentence:
                        if not(all([variable in mapped_positions and \
                                                subsentence_idx in mapped_positions[variable] and  \
                                                atom_subsentence in mapped_positions[variable][subsentence_idx]
                                    for variable in sentence_variables])):
                            self.find_possible_values_in_recursive_tree(atom_subsentence, sentence_variables, target_variables, mapped_positions, possible_values)
                    complex_sentence = list(self.__knowledge_base.get_complex_sentences_by_name(subsentence_name.sentence_name))[0] #TODO: refactor this!!! It's ugly!!!
                    if complex_sentence:
                        if not(all([variable in mapped_positions and variable in target_variables and \
                                                    subsentence_idx in mapped_positions[variable] and  \
                                                    complex_sentence in mapped_positions[variable][subsentence_idx]
                                        for variable in sentence_variables])):
                            self.find_possible_values_in_recursive_tree(complex_sentence, sentence_variables, target_variables, mapped_positions, possible_values)

    def find_possible_values_in_recursive_tree(
            self,
            sentence,
            variables,
            target_variables,
            mapped_positions,
            possible_values):
        """
        Searches for possible values in recursive sentences tree with constraints that allow to avoid infinite loops
        and unlimited recursion
        :param sentence: core.first_order_logic.models.Sentence
        :param variables: list
        :param target_variables: list
        :param mapped_positions: dict
        :param possible_values: dict
        :return: None
        """
        if isinstance(sentence, models.AtomSentence):
            unset_indices = []
            for idx, variable in enumerate(variables):
                if variable in target_variables:
                    mapped_positions.setdefault(variable, dict())
                    mapped_positions[variable].setdefault(idx, set())
                    mapped_positions[variable][idx].add(sentence)
                    unset_indices.append(idx)
            self.find_possible_values_for_atom(sentence,unset_indices, variables, possible_values)
        else:
            #TODO: consider adding complex subentence index here!!!
            for idx, variable in enumerate(variables):
                if variable in target_variables:
                    mapped_positions.setdefault(variable, dict())
                    mapped_positions[variable].setdefault(idx, set())
                    mapped_positions[variable][idx].add(sentence)
            #----------------------------------------------------------------
            dispatched_variables = self.__dispatcher.dispatch_variables(sentence, variables)
            for subsentence_idx, sentence_variables in dispatched_variables.items():
                subsentence_name = sentence.subsentences_names[subsentence_idx]
                if not(self.all_variables_are_set(sentence_variables)):
                    atom_subsentence = self.__knowledge_base.get_atom_by_name(subsentence_name.sentence_name)
                    if atom_subsentence:
                        target_variables_for_sentence = set(target_variables) & set(sentence_variables)
                        if not(all([variable in mapped_positions and \
                                    subsentence_idx in mapped_positions[variable] and  \
                                    atom_subsentence in mapped_positions[variable][subsentence_idx]
                                    for variable in target_variables_for_sentence])):
                            self.find_possible_values_in_recursive_tree(atom_subsentence, sentence_variables, target_variables, mapped_positions, possible_values)
                    complex_sentence = list(self.__knowledge_base.get_complex_sentences_by_name(subsentence_name.sentence_name))[0] #TODO: ugly fix it!
                    if complex_sentence:
                        target_variables_for_sentence = set(target_variables) & set(sentence_variables)
                        for variable in target_variables_for_sentence:
                            if not(subsentence_idx in mapped_positions[variable] and complex_sentence in mapped_positions[variable][subsentence_idx]):
                                for target_variable_for_sentence in target_variables_for_sentence:
                                    mapped_positions.setdefault(target_variable_for_sentence, dict())
                                    mapped_positions[target_variable_for_sentence].setdefault(subsentence_idx, set())
                                    mapped_positions[target_variable_for_sentence][subsentence_idx].add(complex_sentence)
                                self.find_possible_values_in_recursive_tree(complex_sentence, sentence_variables, target_variables, mapped_positions, possible_values)
                                break


    def find_possible_values_for_atom(self, atom, unset_indices, variables, possible_values):
        allowed_values_for_atom = self.__knowledge_base.allowed_values_for_atom(atom)
        for values_set in allowed_values_for_atom:
            for unset_idx in unset_indices:
                variable = variables[unset_idx]
                possible_values.setdefault(variable, [])
                possible_values[variable].append(values_set[unset_idx])

    def find_unset_variables_indices(self, variables, temp_substitutions=None):
        return [
            index
            for index, variable in enumerate(variables)
            if not(self.__knowledge_base.variable_is_set(variable)) and not(temp_substitutions and variable in temp_substitutions)
        ]

    def all_variables_are_set(self, variables, temp_substitutions=None):
        return all([
            self.__knowledge_base.variable_is_set(variable) or (temp_substitutions and variable in temp_substitutions)
            for variable in variables
        ])

    def __raise_unknown_sentence(self, sentence):
        raise AttributeError(str.format("Unknown sentence: {0}", sentence.name))

    def __raise_variables_are_not_set(self):
        raise AttributeError("Not all variables are set!")

    def __raise_invalid_number_of_values_passed_for_atom_evaluation(self, atom_arity, variables_count):
        raise AttributeError(
            str.format("Invalid number of variables passed for atom evaluation. Expected: {0}, variables count {1}",
                       atom_arity, variables_count
        ))
