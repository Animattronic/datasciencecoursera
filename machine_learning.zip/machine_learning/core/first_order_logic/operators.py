__author__ = 'Filip'

class Operator():

    def __init__(self, name, arity = 0):
        self.__name = name
        self.__arity = arity

    @property
    def name(self):
        return self.__name

    @property
    def arity(self):
        return self.__arity

    def params_are_valid(self, partial_results):
        if self.arity != 0:
            return len(partial_results) == self.arity
        else:
            return True

    def evaluate(self, partial_results):
        if self.params_are_valid(partial_results):
            return self.perform_evaluation(partial_results)
        else:
            raise AttributeError("Too many partial results for this logic operator")

    def perform_evaluation(self, partial_results):
        raise NotImplementedError()

    def negate_subsentences(self, subsentences):
        if self.params_are_valid(subsentences):
            return self.perform_negation(subsentences)
        else:
            raise AttributeError("Too many partial results for this logic operator")

    def perform_negation(self, subsentences):
        return [subsentence.negate() for subsentence in subsentences]

    def negate(self):
        raise NotImplementedError()

    def __eq__(self, other):
        if not isinstance(other, Operator):
            return False
        return self.name == other.name and self.arity == other.arity

class And(Operator):

    def __init__(self):
        super().__init__("AND")

    def perform_evaluation(self, partial_results):
        return all(partial_results)

    def negate(self):
        return Or()

class Or(Operator):

    def __init__(self):
        super().__init__("OR")

    def perform_evaluation(self, partial_results):
        return any(partial_results)

    def negate(self):
        return And()

class Pass(Operator):

    def __init__(self):
        super().__init__("", 1)

    def perform_evaluation(self, partial_results):
        return partial_results[0]

    def negate(self):
        return Not()

class Not(Operator):

    def __init__(self):
        super().__init__("NOT", 1)

    def perform_evaluation(self, partial_results):
        return not partial_results[0]

    def negate(self):
        return Pass()
