__author__ = 'Filip'

import pandas as pd
import core.decision_trees.models as models
import math


class InformationGainCalculator():

    def calculate_information_gain(
            self,
            original_data_set,
            splitted_subsets,
            dispersion_measure,
            value_column):
        total_rows_count = original_data_set.shape[0]
        initial_entropy = dispersion_measure(original_data_set, value_column)
        return self.find_information_gain(initial_entropy, total_rows_count, splitted_subsets, dispersion_measure, value_column)

    def find_information_gain(
            self,
            initial_entropy,
            total_rows_count,
            splitted_subsets,
            dispersion_measure,
            value_column):
        raise NotImplementedError()


class SimpleInformationGainCalculator(InformationGainCalculator):

    def find_information_gain(
            self,
            initial_entropy,
            total_rows_count,
            splitted_subsets,
            dispersion_measure,
            value_column):
        weighted_entropies = sum([
            (subset.shape[0]/total_rows_count) * dispersion_measure(subset, value_column)
            for subset in splitted_subsets
        ])
        return initial_entropy - weighted_entropies


class InformationGainRatioCalculator(SimpleInformationGainCalculator):

    def calculate_intrinsic_information(self, splitted_subsets, total_rows_count):
        intrinsic_value = -1 * sum([
            (subset.shape[0] / total_rows_count) * math.log((subset.shape[0] / total_rows_count), 2)
            for subset in splitted_subsets
        ])
        return intrinsic_value

    def find_information_gain(
            self,
            initial_entropy,
            total_rows_count,
            splitted_subsets,
            dispersion_measure,
            value_column):
        intrinsic_value = self.calculate_intrinsic_information(splitted_subsets, total_rows_count)
        information_gain = super().find_information_gain(initial_entropy, total_rows_count, splitted_subsets, dispersion_measure, value_column)
        return information_gain / intrinsic_value


class SplitSelector():

    def __init__(self, numeric_split_selector, dispersion_measure, information_gain_calculator):
        self.__numeric_split_selector = numeric_split_selector
        self.__dispersion_measure = dispersion_measure
        self.__information_gain_calculator = information_gain_calculator

    @property
    def dispersion_measure(self):
        return self.__dispersion_measure

    @property
    def information_gain_calculator(self):
        return self.__information_gain_calculator

    @property
    def numeric_split_selector(self):
        return self.__numeric_split_selector

    def select_best_split_data(
            self,
            data,
            value_column,
            already_used_columns=[]):
        """
        @type data: pandas.core.frame.DataFrame
        @type information_gain_calculator: InformationGainCalculator
        """
        initial_dispersion = self.dispersion_measure(data, value_column)
        columns_to_select = [
            column_name for column_name in data.columns
            if not(column_name in already_used_columns or column_name == value_column)
        ]
        best_information_gain = -float("inf")
        best_split_option = None
        numerical_columns = [
            column_name for column_name in data.columns
            if data.dtypes[column_name] in ['int64', 'float64']
            and not column_name == value_column
        ]
        numerical_data = data[numerical_columns]
        for split_column in columns_to_select:
            if split_column in numerical_data:
                current_split_option, split_information_gain = self.split_numeric_data(data, value_column, split_column)
            else:
                current_split_option, split_information_gain = self.get_split_data(data, value_column, split_column, initial_dispersion)
            if split_information_gain > best_information_gain:
                best_information_gain = split_information_gain
                best_split_option = current_split_option
        return best_split_option

    def split_numeric_data(self, data, value_column, numeric_column):
        numeric_split_option, information_gain = self.numeric_split_selector.select_best_numeric_split(
                    data,
                    value_column,
                    numeric_column,
                    self.dispersion_measure,
                    self.information_gain_calculator)
        return numeric_split_option, information_gain

    def get_split_data(self, data, value_column, split_column, initial_dispersion):
        discrete_split_option = self.split


class NumericSplitSelector():

    def select_best_numeric_split(
            self,
            data,
            value_column,
            numeric_column,
            dispersion_measure,
            information_gain_calculator):
        """
        @type data: pandas.core.frame.DataFrame
        @type information_gain_calculator: InformationGainCalculator
        """
        initial_dispersion = dispersion_measure(data, value_column)
        results = dict()
        sorted_data = data.sort(columns=[numeric_column])
        previous_class = None
        previous_numeric_val = None
        for row_idx, row in sorted_data.iterrows():
            row_value = row[value_column]
            row_numeric_val = row[numeric_column]
            if previous_class is None:
                previous_class = row_value
                previous_numeric_val = row_numeric_val
                continue
            else:
                if row_value != previous_class:
                    half_way = previous_numeric_val + (row_numeric_val - previous_numeric_val) / 2
                    previous_class = row_value
                    previous_numeric_val = row_numeric_val
                    lower_data = sorted_data.loc[:row_idx, :]
                    higher_data = sorted_data.loc[row_idx:, :]
                    information_gain = information_gain_calculator.find_information_gain(
                        initial_dispersion,
                        data.shape[0],
                        [lower_data, higher_data],
                        dispersion_measure,
                        value_column)
                    results.setdefault(half_way, 0)
                    results[half_way] = information_gain
        sorted_results = sorted(results.items(), key=lambda elem: elem[1], reverse=True)
        best_result = sorted_results[0]
        return models.SplitOption(numeric_column, best_result[0], True), best_result[1]


class MultiValueSplitSelector(SplitSelector):

    def __init__(self, numeric_split_selector, dispersion_measure, information_gain_calculator):
        """

        @type numeric_split_selector: NumericSplitSelector
        :return:
        """
        super().__init__(numeric_split_selector, dispersion_measure, information_gain_calculator)

    def get_split_data(self, data, value_column, split_column, initial_dispersion):
        unique_values = data[split_column].unique()
        #TODO: add missing values handling!
        values_and_gains = []
        subsets = []
        for value in unique_values:
            subset = data[data[split_column] == value]
            subsets.append(subset)
        information_gain = self.information_gain_calculator.find_information_gain(
            initial_dispersion,
            data.shape[0],
            subsets,
            self.dispersion_measure,
            value_column)
        return models.SplitOption(split_column), information_gain


class BinarySplitSelector(SplitSelector):

    def __init__(self, numeric_split_selector, dispersion_measure, information_gain_calculator):
        super().__init__(numeric_split_selector, dispersion_measure, information_gain_calculator)

    def get_split_data(self, data, value_column, split_column, initial_dispersion):
        #TODO: add missing values handling
        unique_values = data[split_column].unique()
        highest_information_gain_for_column = - float("inf")
        best_split_for_column = None
        for current_value in unique_values:
            query_vector = data[split_column] == current_value
            positive_subset = data[query_vector]
            negative_subset = data[~query_vector]
            total_dispersion = 0
            information_gain = self.information_gain_calculator.find_information_gain(
                initial_dispersion,
                data.shape[0],
                [positive_subset, negative_subset],
                self.dispersion_measure,
                value_column)
            if information_gain > highest_information_gain_for_column:
                highest_information_gain_for_column = information_gain
                best_split_for_column = models.SplitOption(split_column, current_value)
        return best_split_for_column, highest_information_gain_for_column


class Predictor():

    def __init__(self, decision_tree, value_column):
        self.__decision_tree = decision_tree
        self.__value_column = value_column

    def predict(self, queries):
        results = []
        for idx, row in queries.iterrows():
            results.append(self.process_query(row, self.__decision_tree))
        return results

    def process_query(self, query, tree_node):
        """
        Processes given query, with a given tree node
        :type query: pandas.core.series.Series
        :type tree_node: core.decision_trees.models.DecisionNode
        """
        if not tree_node.has_children:
            return tree_node.single_decision_value[0]
        else:
            # TODO: add missing values handling
            decision_attribute = tree_node.decision_attribute_name
            children_by_value = {link.value: link.node for link in tree_node.children}
            single_decision_value = tree_node.single_decision_value
            query_value = query[decision_attribute]
            if tree_node.is_decision_value_numeric:
                    lesser_than = query_value < single_decision_value
                    return self.process_query(query, children_by_value[lesser_than])
            if tree_node.has_single_decision_value:
                return self.process_query(query, children_by_value[query_value == single_decision_value])
            else:
                return self.process_query(query, children_by_value[query_value])