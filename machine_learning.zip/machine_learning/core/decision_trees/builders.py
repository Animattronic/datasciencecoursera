__author__ = 'Filip'

import pandas as pd
import core.decision_trees.models as models


class DecisionTreeBuilder():

    def __init__(self, split_selector):
        """
        Generic decision tree builder
        @type split_selector: core.decision_trees.builders.SplitSelector
        """
        self.__split_selector = split_selector

    def build_model(self, data, value_column, already_used_columns=[]):
        total_rows = data.shape[0]
        unique_values_count = len(data[value_column].unique())
        if total_rows == 1 or unique_values_count == 1 or len(already_used_columns) == (len(data.columns) - 1):
            return models.DecisionNode(value_column, data[value_column].unique(), data=data)
        else:
            best_split = self.__split_selector.select_best_split_data(data, value_column, already_used_columns)
            if not best_split.numerical_split: already_used_columns.append(best_split.split_column)
            splitting_results = self.split_data(data, best_split)
            decision_node = models.DecisionNode(best_split.split_column, best_split.split_value)
            initial_data_count = data.shape[0]
            for decision_val, split_data in splitting_results.items():
                if any(split_data):
                    child_node = self.build_model(split_data, value_column, already_used_columns)
                    proportion = split_data.shape[0] / initial_data_count
                    class_distribution = split_data[value_column].value_counts(normalize=True)
                    child_link = models.ChildLinkValue(decision_val, child_node, proportion, class_distribution)
                    decision_node.add_child(child_link)

            return decision_node

    def split_data(self, data, split):
        split_column = split.split_column
        split_value = split.split_value
        if split_value:
            if split.numerical_split:
                true_data_set = data[data[split_column] >= split_value]
                false_data_set = data[data[split_column] < split_value]
                return {
                    True: true_data_set,
                    False: false_data_set
                }
            else:
                true_data_set = data[data[split_column] == split_value]
                false_data_set = data[data[split_column] != split_value]
                return {
                    True: true_data_set,
                    False: false_data_set
                }
        else:
            unique_column_values = data[split_column].unique()
            results = dict()
            for value in unique_column_values:
                results[value] = data[data[split_column] == value]
            return results