__author__ = 'Filip'

import pandas as pd
import math


def shannon_entropy(data, value_column):
    normalized_values_counts = pd.value_counts(data[value_column], normalize=True)
    entropy = - sum([elem * math.log(elem, 2) for elem in normalized_values_counts])
    return entropy


def gini_index(data, value_column):
    normalized_values_counts = pd.value_counts(data[value_column], normalize=True)
    gini_index = 1 - sum([prob ** 2 for prob in normalized_values_counts])
    return gini_index
