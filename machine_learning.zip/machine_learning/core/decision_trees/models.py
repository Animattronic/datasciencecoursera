from abc import abstractproperty

__author__ = 'Filip'

from copy import deepcopy
from abc import ABCMeta, abstractmethod, abstractproperty
import pandas as pd


def is_number(value):
    try:
        val = float(value)
        return True
    except ValueError:
        return False


class SplitOption():

    def __init__(self, split_column, split_value=None, numerical_split=False):
        self.__split_column = split_column
        self.__split_value = split_value
        self.__numerical_split = numerical_split

    @property
    def split_column(self):
        return self.__split_column

    @property
    def split_value(self):
        return self.__split_value

    @property
    def numerical_split(self):
        return self.__numerical_split

    @property
    def instances_count(self):
        return self.__instances_count

    def __eq__(self, other):
        if not(isinstance(other, SplitOption)):
            return False
        else:
            return self.__split_value == other.split_value and \
                    self.split_column == other.split_column and \
                    self.numerical_split == other.numerical_split


class ChildLinkValue():

    def __init__(self, value, node, probability=1.0, class_distribution=pd.Series()):
        self.__value = value
        self.__node = node
        self.__probability = probability
        self.__class_distribution = class_distribution

    @property
    def value(self):
        return self.__value

    @property
    def node(self):
        return self.__node

    @property
    def probability(self):
        return self.__probability

    @property
    def class_distribution(self):
        return self.__class_distribution


class DecisionNode():

    __metaclass__ = ABCMeta

    def __init__(self, decision_attribute_name, single_decision_value=None, data=None):
        self.__decision_attribute_name = decision_attribute_name
        self.__single_decision_value = single_decision_value
        self.__children = []
        self.__data = data

    @property
    def decision_attribute_name(self):
        return self.__decision_attribute_name

    @property
    def single_decision_value(self):
        return self.__single_decision_value

    @property
    def has_single_decision_value(self):
        return not(self.single_decision_value is None)

    @property
    def is_decision_value_numeric(self):
        if self.has_single_decision_value:
            return is_number(self.single_decision_value)
        return False

    @property
    def data(self):
        return self.__data

    @property
    def has_children(self):
        return any(self.children)

    @property
    def children(self):
        return self.__children

    def add_child(self, child_link_value):
        self.__children.append(child_link_value)


class BinaryDecisionNode(DecisionNode):

    def __init__(self, decision_attribute_name, single_decision_value):
        super().__init__(decision_attribute_name, single_decision_value)

    def add_child(self, value, node, probability=1.0):
        if len(self.__children) == 2:
            raise AttributeError("Too many children for binary decision tree")
        super().add_child(value, node, probability)