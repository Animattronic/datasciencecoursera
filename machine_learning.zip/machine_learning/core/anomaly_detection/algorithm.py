__author__ = 'Filip'

import numpy as np
import math
import scipy.stats as stats
import matplotlib.pyplot as plt

def gaussian(elem, mean, sigma):
    distribution = stats.norm(mean, sigma)
    return distribution.pdf(elem)

class AnomalyDetector():

    def find_anomalies(self, data, epsilon):
        means = np.mean(data, axis = 0)
        stds = np.std(data, axis = 0)
        func = self.find_probability_of_row(means, stds)
        results = np.apply_along_axis(func, 1, data)
        return np.where(results < epsilon)

    def find_probability_of_row(self, means, stds):
        def find_probability(row):
            return np.prod([ gaussian(elem, means[idx], stds[idx]) for idx, elem in enumerate(row) ])
        return find_probability

    def find_probability_of_row2(self, means, stds):
        def find_probability(row):
            return np.sum([ np.log(gaussian(elem, means[idx], stds[idx])) for idx, elem in enumerate(row) ])
        return find_probability

"""
data = np.array([
    [1, 34],
    [5, 51],
    [6, 62],
    [8, 85],
    [5.5, 51.6],
    [6.5, 62.3],
    [8.5, 85.9],
    [11, 131],
    [12, 121],
    [12, 123],
    [15, 151],
    [15, 152],
    [15, 156],
    [15, 157],
    [16, 161],
    [17, 192],
    [17, 182],
    [17, 132],
    [18, 182],
    [18.5, 195],
    [18.4, 194],
    [19.2, 132],
    [22, 220],
    [23, 221],
    [25, 232],
    [22.3, 245],
    [23.2, 229],
    [25.1, 219]
])
#means = np.mean(data, axis=0)
#stds = np.std(data, axis=0)

detector = AnomalyDetector()
"""
