__author__ = 'Filip'

import numpy as np
import scipy as sp

class ErrorFunction():

    def calculate_error(self, y, yhat):
        raise NotImplementedError()

    def calculate_derivative(self, y, yhat):
        raise NotImplementedError()

class MeanSquareError(ErrorFunction):

    def calculate_error(self, y, yhat):
        return (np.sum(np.power(y - yhat, 2)))/len(y)

    def calculate_derivative(self, y, yhat):
        return (y - yhat)