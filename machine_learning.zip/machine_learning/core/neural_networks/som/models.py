__author__ = 'Filip'

from copy import deepcopy
import numpy as np
import math
import scipy.spatial.distance as dist
import core.neural_networks.som.functions as functions

class Node():

    def __init__(self, x, y, weights_size):
        self.__x = x
        self.__y = y
        self.__weights = np.random.rand(1, weights_size)

    @property
    def x(self):
        return self.__x

    @property
    def y(self):
        return self.__y

    @property
    def weights(self):
        return self.__weights

    @weights.setter
    def weights(self, values):
        if values.shape != self.__weights.shape:
            raise AttributeError("Invalid shape of weights passed!")
        self.__weights = np.copy(values)

class SOM():

    def __init__(
            self,
            nodes_count,
            input_size,
            distance_function,
            neighborhood_function,
            initial_radius,
            time_constant,
            initial_learning_rate = 0.01):
        self.__nodes_count = nodes_count
        self.__dimsize = int(nodes_count / 2)
        self.__distance_function = distance_function
        self.__neighborhood_function = neighborhood_function
        self.__initial_radius = initial_radius
        self.__time_constant = time_constant
        self.__input_size = input_size
        self.__nodes = []
        self.__initial_learning_rate = initial_learning_rate

        self.__build_nodes()

    def __build_nodes(self):
        for i in range(self.__dimsize):
            nodes_row = []
            for j in range(self.__dimsize):
                nodes_row.append(Node(i, j, self.__input_size))
            self.__nodes.append(nodes_row)

    @property
    def nodes(self):
        return self.__nodes

    def learning_rate_for_iteration(self, iteration):
        return self.rate_for_iteration(self.__initial_learning_rate, iteration)

    def radius_for_iteration(self, iteration):
        return self.rate_for_iteration(self.__initial_radius, iteration)

    def rate_for_iteration(self, value, iteration):
        return value * np.exp(- iteration/self.__time_constant)

    def find_bmu_node(self, input):
        best_node = None
        closest_distance = float("inf")
        for i in range(self.__dimsize):
            for j in range(self.__dimsize):
                node = self.__nodes[i][j]
                distance = self.__distance_function(node.weights, input)
                if distance < closest_distance:
                    closest_distance = distance
                    best_node = node
        return best_node

    def update_weights(self, bmu_node, input, iteration):
        learning_rate_for_iteration = self.learning_rate_for_iteration(iteration)
        radius_for_iteration = self.radius_for_iteration(iteration)
        for i in range(self.__dimsize):
            for j in range(self.__dimsize):
                node = self.__nodes[i][j]
                if node == bmu_node:
                    continue
                distance = self.__distance_function(bmu_node.weights, node.weights)
                neighborhood_ratio = self.__neighborhood_function(distance, radius_for_iteration)
                node.weights += neighborhood_ratio * learning_rate_for_iteration * (input - node.weights)

    def train(self, data, iterations):
        for i in range(iterations):
            row_indices = list(range(data.shape[0]))
            np.random.shuffle(row_indices)
            for row_idx in row_indices:
                row = data[row_idx, :]
                bmu = self.find_bmu_node(row)
                self.update_weights(bmu, row, i)


data = np.genfromtxt('iris.txt', delimiter=',')
np.random.shuffle(data)
training_data_count = int(0.75 * data.shape[0])
training_data = data[:training_data_count,]
test_data = data[training_data_count:,]
time_constant = 100 / math.log(2)
initial_radius = 1
som = SOM(4, 4, dist.euclidean, functions.gaussian_neighborhood_function, initial_radius, time_constant, 0.1)
som.train(training_data[:, list(range(4))], 100)

expected_actuals = {}
for row in test_data:
    bmu = som.find_bmu_node(row[list(range(4)),])
    x, y = bmu.x, bmu.y
    coords = ','.join(list(map(str, [x, y])))
    expected = ','.join(list(map(str, row[-3:])))
    expected_actuals.setdefault(expected, [])
    expected_actuals[expected].append(coords)

for elem in expected_actuals:
    print(elem)
    print(expected_actuals[elem])
    print("----")
