__author__ = 'Filip'

import numpy as np

def gaussian_neighborhood_function(distance, radius_size):
    return np.exp(distance ** 2 / (2 * radius_size ** 2))
