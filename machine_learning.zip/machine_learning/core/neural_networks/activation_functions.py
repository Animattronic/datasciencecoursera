__author__ = 'Filip'

import numpy as np
import math as math

class ActivationFunction():

    def calculate_output(self, sums):
        """
        Calculates output of activation function
        @param sums: list
        @return: list
        """
        raise NotImplementedError()

    def calculate_derivative(self, outputs):
        """
        Calculates derivative of activation function
        @param outputs: list outputs of activation function
        @return: list
        """
        raise NotImplementedError()

class BipolarActivation(ActivationFunction):

    def calculate_output(self, sums):
        results = np.copy(sums)
        results[results >= 0.0] = 1.0
        results[results < 0] = -1.0
        return results

class SigmoidActivationFunction(ActivationFunction):

    def calculate_output(self, sums):
        return 1 / (1 + np.exp(-sums))

    def calculate_derivative(self, outputs):
        copied_outputs = np.copy(outputs)
        return copied_outputs * (1 - copied_outputs)

class SoftmaxActivaitonFunction(ActivationFunction):

    def calculate_output(self, sums):
        normalisers = np.sum(np.exp(sums)) * np.ones((1, sums.shape[0]))
        return ((np.exp(sums)).T / normalisers).T

    def calculate_derivative(self, outputs):
        ncol = outputs.shape[1]
        results = [0 for i in range(ncol)]
        for col_idx in range(ncol):
            value = outputs[0, col_idx]
            if value > 45.0:
                results[col_idx] = 1.0
            elif value < -45.0:
                results[col_idx] = 0.0
            else:
                results[col_idx] = 1.0/(1.0 + math.exp(-value))
        return np.array(results).reshape((1, ncol))

class HyperTangentActivationFunction(ActivationFunction):

    def calculate_output(self, sums):
        return np.tanh(sums)

    def calculate_derivative(self, outputs):
        return (1 - outputs) * (1 + outputs)