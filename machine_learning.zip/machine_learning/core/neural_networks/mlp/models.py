__author__ = 'Filip'

import numpy as np
import core.neural_networks.error_functions as errors
from enum import Enum

NetworkLayerType = Enum("Type", "input hidden output")

class NeuralNetworkLayer():
    """
    Represents general purpose neural network layer
    """

    def __init__(self, neurons_count, next_layer_count, activation_function):
        super().__init__()
        self.__neurons_count = neurons_count
        self.__next_layer_neurons_count = next_layer_count
        self.__activation_function = activation_function
        self.__next_layer_weights = np.ones((self.__neurons_count, self.__next_layer_neurons_count))
        self.__biases  = np.ones((1, self.__neurons_count))
        self.__outputs = np.ones((1, self.__neurons_count))
        self.build_matrices()

    @property
    def neurons_count(self):
        return self.__neurons_count

    @property
    def next_layer_neurons_count(self):
        return self.__next_layer_neurons_count

    @property
    def activation_function(self):
        return self.__activation_function

    @property
    def next_layer_weights(self):
        return np.copy(self.__next_layer_weights)

    @next_layer_weights.setter
    def next_layer_weights(self, value):
        if value.shape != self.__next_layer_weights.shape:
            raise AttributeError("Invalid shape of weights passed!")
        self.__next_layer_weights = np.copy(value)

    @property
    def biases(self):
        return np.copy(self.__biases)

    @biases.setter
    def biases(self, value):
        if value.shape != self.__biases.shape:
            raise AttributeError("Invalid shape of biases passed!")
        self.__biases = np.copy(value)

    @property
    def outputs(self):
        return np.copy(self.__outputs)

    @outputs.setter
    def outputs(self, value):
         if value.shape != self.__outputs.shape:
            raise AttributeError("Invalid shape of outputs passed!")
         self.__outputs = value

    def build_matrices(self):
        weights_count = self.__neurons_count * self.__next_layer_neurons_count
        weights = [np.random.uniform(0, 0.1) for i in range(weights_count)]
        self.__next_layer_weights = np.array(weights).reshape((self.__neurons_count, self.__next_layer_neurons_count))

        biases = [np.random.uniform(0, 0.1) for i in range(self.__neurons_count)]
        self.__biases = np.array(biases).reshape((1, self.__neurons_count))

    def calculate_output(self, input):
        biased_input = input + self.__biases
        self.__outputs = self.__activation_function.calculate_output(biased_input)
        return np.copy(self.__outputs)

class NeuralNetworkInputLayer(NeuralNetworkLayer):

    def __init__(self, neurons_count, next_layer_count, activation_function):
        super().__init__(neurons_count, next_layer_count, activation_function)

    def calculate_output(self, input):
        self.outputs = np.copy(input)
        return input

class NetworkLayerFactory():

    def build_network_layer(self, neurons_count, next_layer_neurons_count, activation, layer_type):
        """
        Network layer factory
        @param neurons_count: int
        @param next_layer_neurons_count: int
        @param activation: ActivationFunction
        @param layer_type: NetworkLayerType
        @return: NeuralNetworkLayer
        """
        if layer_type == NetworkLayerType.input:
            return NeuralNetworkInputLayer(neurons_count, next_layer_neurons_count, activation)
        else:
            return NeuralNetworkLayer(neurons_count, next_layer_neurons_count, activation)

class NeuralNetwork():

    def __init__(self,
                 inputs_count,
                 hidden_layers_count,
                 hidden_neurons_count,
                 outputs_count,
                 hidden_activation,
                 outputs_activation,
                 error_function,
                 factory):
        """
        Builds new neural network with proper configuration per each layer
        @param inputs_count: int
        @param hidden_layers_count: int
        @param hidden_neurons_count: int
        @param outputs_count: int
        @param hidden_activation: ActivationFunction
        @param outputs_activation: ActivationFunction
        @param error_function: ErrorFunction
        @param factory: NetworkLayerFactory
        """
        self.__hidden_layers_count = hidden_layers_count
        self.__layers = []
        self.__error_function = error_function
        for i in range(self.__hidden_layers_count + 2):
            if i == 0:
                self.__layers.append(factory.build_network_layer(inputs_count, hidden_neurons_count, None, NetworkLayerType.input))
            elif i == (self.__hidden_layers_count + 1):
                self.__layers.append(factory.build_network_layer(outputs_count, 0, outputs_activation, NetworkLayerType.output))
            elif i == (self.__hidden_layers_count):
                self.__layers.append(factory.build_network_layer(hidden_neurons_count, outputs_count, hidden_activation, NetworkLayerType.hidden))
            else:
                self.__layers.append(factory.build_network_layer(hidden_neurons_count, hidden_neurons_count, hidden_activation, NetworkLayerType.hidden))
    @property
    def error_function(self):
        return self.__error_function

    @property
    def layers_count(self):
        return self.__hidden_layers_count + 2

    @property
    def outputs_count(self):
        return self.__layers[-1].neurons_count

    @property
    def inputs_count(self):
        return self.__layers[0].neurons_count

    def __getitem__(self, index):
        return self.__layers[index]

    def calculate_outputs(self, input):
        last_output = input
        for i in range(self.layers_count):
            layer = self[i]
            layer_output = layer.calculate_output(last_output)
            if i != (self.layers_count - 1):
                layer_output = layer_output.dot(layer.next_layer_weights)
            last_output = layer_output
        return last_output




