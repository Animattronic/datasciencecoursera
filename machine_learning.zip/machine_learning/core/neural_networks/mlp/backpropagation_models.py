__author__ = 'Filip'

import numpy as np
import pandas as pd
import core.neural_networks.activation_functions as activations
import core.neural_networks.mlp.models as models

class BackpropagationLayer(models.NeuralNetworkLayer):

    def __init__(self, neurons_count, next_layer_count, activation_function):
        super().__init__(neurons_count, next_layer_count, activation_function)

        self.__gradients = np.ones((1, self.neurons_count))
        self.__biases_delta = np.ones((1, self.neurons_count))
        self.__previous_biases_delta = np.ones((1, self.neurons_count))
        self.__previous_weights_delta = np.ones((self.neurons_count, self.next_layer_neurons_count))

    @property
    def gradients(self):
        return np.copy(self.__gradients)

    @gradients.setter
    def gradients(self, value):
        if self.gradients.shape != value.shape:
            raise AttributeError("Invalid shape of values passed!")
        self.__gradients = value

    @property
    def biases_delta(self):
        return np.copy(self.__biases_delta)

    @biases_delta.setter
    def biases_delta(self, value):
        if self.__biases_delta.shape != value.shape:
            raise AttributeError("Invalid shape of values passed!")
        self.__biases_delta = value

    @property
    def previous_biases_delta(self):
        return np.copy(self.__previous_biases_delta)

    @previous_biases_delta.setter
    def previous_biases_delta(self, value):
        if self.__previous_biases_delta.shape != value.shape:
            raise AttributeError("Invalid shape of values passed!")
        self.__previous_biases_delta = value

    @property
    def previous_weights_delta(self):
        return np.copy(self.__previous_weights_delta)

    @previous_weights_delta.setter
    def previous_weights_delta(self, value):
        if self.__previous_weights_delta.shape != value.shape:
            raise AttributeError("Invalid shape of values passed!")
        self.__previous_weights_delta = value

    def calculate_gradients(self, next_layer_values, error_function):
        raise NotImplementedError()

    def update_weights(self, next_layer_deltas, learning_rate, momentum):
        updates = learning_rate * self.outputs.T * next_layer_deltas
        total_updates = updates + self.previous_weights_delta * momentum
        self.previous_weights_delta = np.copy(updates)
        self.next_layer_weights = self.next_layer_weights + total_updates

    def update_biases(self, learning_rate, momentum):
        updates = self.gradients * learning_rate
        total_updates = updates + momentum * self.previous_biases_delta
        self.biases += total_updates
        self.previous_biases_delta = updates

class BackpropagationOutputLayer(BackpropagationLayer):

    def __init__(self, neurons_count, next_layer_count, activation_function):
        super().__init__(neurons_count, next_layer_count, activation_function)

    def calculate_gradients(self, expected_outputs, error_function):
        diff = error_function.calculate_derivative(expected_outputs, self.outputs)
        derivatives = self.activation_function.calculate_derivative(self.outputs)
        self.gradients = derivatives * diff

    def update_weights(self, next_layer_deltas, learning_rate, momentum):
        pass

class BackpropagationHiddenLayer(BackpropagationLayer):

    def __init__(self, neurons_count, next_layer_count, activation_function):
        super().__init__(neurons_count, next_layer_count, activation_function)

    def calculate_gradients(self, next_layer_gradients, error_function):
        weights_and_gradients_dot = np.dot(next_layer_gradients, self.next_layer_weights.T)
        derivatives = self.activation_function.calculate_derivative(self.outputs)
        self.gradients = weights_and_gradients_dot * derivatives

class BackPropagationInputLayer(BackpropagationLayer, models.NeuralNetworkInputLayer):

    def __init__(self, neurons_count, next_layer_count, activation_function):
        super().__init__(neurons_count, next_layer_count, activation_function)

    def calculate_gradients(self, next_layer_values, error_function):
        pass

    def update_biases(self, learning_rate, momentum):
        pass

    def update_weights(self, next_layer_deltas, learning_rate, momentum):
        updates = learning_rate * self.outputs.T * next_layer_deltas
        total_updates = updates + self.previous_weights_delta * momentum
        self.previous_weights_delta = np.copy(updates)
        self.next_layer_weights += total_updates

class BackpropagationLayerFactory(models.NetworkLayerFactory):

    types = {
        models.NetworkLayerType.input: BackPropagationInputLayer,
        models.NetworkLayerType.hidden: BackpropagationHiddenLayer,
        models.NetworkLayerType.output: BackpropagationOutputLayer
    }

    def build_network_layer(self, neurons_count, next_layer_neurons_count, activation, layer_type):
        return self.types[layer_type](neurons_count, next_layer_neurons_count, activation)

class BackPropagationNetwork(models.NeuralNetwork):

    def __init__(self,
        inputs_count,
        hidden_layers_count,
        hidden_neurons_count,
        outputs_count,
        hidden_activation,
        outputs_activation,
        error_function,
        factory):
        super().__init__(
            inputs_count,
            hidden_layers_count,
            hidden_neurons_count,
            outputs_count,
            hidden_activation,
            outputs_activation,
            error_function,
            factory)

    def perform_backpropagation(self, target_values, learning_rate, momentum):
        self.calculate_gradients(target_values, learning_rate, momentum)
        self.update_weights(learning_rate, momentum)

    def calculate_gradients(self, target_values, learning_rate, momentum):
        current_target_values = np.copy(target_values)
        for layer_idx in list(reversed(range(self.layers_count))):
            current_layer = self[layer_idx]
            current_layer.calculate_gradients(current_target_values, self.error_function)
            current_target_values = current_layer.gradients

    def update_weights(self, learning_rate, momentum):
        for i in range(self.layers_count - 1):
            current_layer = self[i]
            next_layer = self[i + 1]
            next_layer_gradients = next_layer.gradients
            current_layer.update_weights(next_layer_gradients, learning_rate, momentum)
            current_layer.update_biases(learning_rate, momentum)
        self[-1].update_biases(learning_rate, momentum)