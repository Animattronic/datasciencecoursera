__author__ = 'Filip'

import numpy as np
from enum import Enum

TrainingPhase = Enum("Training phase", "training test")

class TrainingStrategy():
    """
    Divides data and guides the training process
    """

    def __init__(self, training_data_percentage, iterations):
        if training_data_percentage < 0 or training_data_percentage > 1:
            raise AttributeError("Invalid percentage passed! Valid numbers are in range (0, 1)")
        self.training_data_percentage = training_data_percentage
        self.iterations = iterations

    def train(self, data, dependent_column_indices, neural_network, network_trainer, problem_domains):
        raise NotImplementedError()

class HoldOutTrainingStrategy(TrainingStrategy):

    def __init__(self, training_data_percentage, iterations):
        super().__init__(training_data_percentage, iterations)

    def train(self, data, dependent_column_indices, neural_network, network_trainer, problem_domains):
        nrow, ncol = data.shape
        training_data_count = int(nrow/self.training_data_percentage)
        y = data[:, dependent_column_indices]
        indices = [elem for elem in  list(range(ncol)) if not elem in dependent_column_indices]
        x = data[:, indices]
        row_indices = list(range(nrow))
        np.random.permutation(row_indices)
        training_data_indices = row_indices[:training_data_count]
        test_data_indices = row_indices[:training_data_count]
        for i in range(self.iterations):
            training_data = x[training_data_indices,:]
            targets = y[training_data_indices,:]
            network_trainer.process_training_data(training_data, targets, neural_network, i, problem_domains)
        test_data = x[test_data_indices,:]
        targets = y[test_data_indices,:]
        network_trainer.process_test_data(test_data, targets, neural_network, problem_domains)

class NeuralNetworkTrainer():
    """
    Class for performing neural network training
    """

    def __init__(self, error_function, data_quality_logger, training_strategy):
        self.data_quality_logger = data_quality_logger
        self.error_function = error_function
        self.training_strategy = training_strategy

    def train(self, data, expected_values, neural_network, problem_domains):
        self.training_strategy.train(self, data, expected_values, neural_network, problem_domains)

    def process_training_data(self, training_data, targets, iteration, neural_network, problem_domains):
        raise NotImplementedError()

    def process_test_data(self, test_data, targets, iteration, neural_network, problem_domains):
        raise NotImplementedError()

    def calculate_error(self, data, targets, neural_network, iteration):
        error = 0
        ncol = data.shape[1]
        for i in range(len(data)):
            row = data[i, :].reshape((1, ncol))
            expected = targets[i, :]
            actual = neural_network.calculate_outputs(row)
            error += self.error_function(expected, actual)
        self.data_quality_logger.log(error, iteration)
        return error

class BackPropagationTrainer(NeuralNetworkTrainer):

    def __init__(self, error_function, data_quality_logger, training_strategy, learning_rate = 0.05, momentum = 0.001):
        super().__init__(error_function, data_quality_logger, training_strategy)
        self.learning_rate = learning_rate
        self.momentum = momentum

    def process_training_data(self, training_data, targets, iteration, neural_network, problem_domains):
        ncol = training_data.shape[1]
        for i in range(training_data.shape[0]):
            row = training_data[i, :].reshape((1, ncol))
            expected = targets[i, :]
            actual = neural_network.calculate_outputs(row)
            neural_network.perform_backpropagation(expected, self.learning_rate, self.momentum)

    def process_test_data(self, test_data, targets, iteration, neural_network, problem_domains):
        self.calculate_error(test_data, targets, neural_network, -1)

class OptimizationBasedTrainer(NeuralNetworkTrainer):

    def __init__(self, optimization_algorithm, training_strategy, iterations, error_function, data_quality_logger):
        super().__init__(error_function, data_quality_logger, training_strategy)
        self.__optimization_algorithm = optimization_algorithm
        self.__iterations = iterations

    def process_training_data(self, training_data, targets, iteration, neural_network, problem_domains):
        cost_function = self.build_cost_function(neural_network, training_data, targets)
        final_weights = self.__optimization_algorithm.solve_problem(problem_domains, cost_function, self.__iterations)
        self.setup_network_weights(neural_network, final_weights)

    def process_test_data(self, test_data, targets, iteration, neural_network, problem_domains):
        self.calculate_error(test_data, targets, neural_network, self.__iterations + 1)

    def build_cost_function(self, neural_network, x, y):
        def cost_function(weights):
            self.setup_network_weights(neural_network, weights)
            error = self.calculate_error(x, y, neural_network, 0)
            return error
        return cost_function

    def setup_network_weights(self, neural_network, weights):
        inputs_count = neural_network.inputs_count
        hidden_layers_count = neural_network.layers_count - 2
        outputs_count = neural_network.outputs_count
        inputs_to_hidden_weights_count = inputs_count * neural_network[1].neurons_count
        inputs_to_hidden_weights = np.array(weights[:inputs_to_hidden_weights_count]).reshape((inputs_count, neural_network[1].neurons_count))
        neural_network[0].next_layer_weights = inputs_to_hidden_weights
        weights = weights[inputs_to_hidden_weights_count:]
        for current_layer_idx in range(1, hidden_layers_count + 1):
            current_layer = neural_network[current_layer_idx]
            current_layer_neurons_count = current_layer.neurons_count
            next_layer_neurons_count = current_layer.next_layer_neurons_count

            current_layer.biases = np.array(weights[:current_layer_neurons_count]).reshape((1, current_layer_neurons_count))
            weights = weights[current_layer_neurons_count:]
            next_layer_weights_count = current_layer_neurons_count * next_layer_neurons_count
            current_layer.next_layer_weights = np.array(weights[:next_layer_weights_count]).reshape((current_layer_neurons_count, next_layer_neurons_count))
            weights = weights[next_layer_weights_count:]
        neural_network[-1].biases = np.array(weights[:neural_network[-1].neurons_count]).reshape((1, outputs_count))



