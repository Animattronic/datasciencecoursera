__author__ = 'Filip'

import numpy as np

class TrainingStrategy():

    def __init__(self, iterations, training_data_percent):
        self.__training_data_percent_is_valid(training_data_percent)

        self.__iterations = iterations
        self.__training_data_percent = training_data_percent

    @property
    def training_data_percent(self):
        return self.__training_data_percent

    @property
    def test_data_percent(self):
        return 1 - self.training_data_percent

    @property
    def iterations(self):
        return self.__iterations

    def __training_data_percent_is_valid(self, training_data_percent):
        if (training_data_percent > 0.0) and (training_data_percent < 1.0):
            return
        raise AttributeError(training_data_percent)

    def train(self, evaluator, data, expected_values, *algorithm_specific_objects):
        raise NotImplementedError()

class HoldOutTraining(TrainingStrategy):

    def __init__(self, iterations, training_data_percent):
        super().__init__(iterations, training_data_percent)

    def train(self, evaluator, data, expected_values, *algorithm_specific_objects):
        nrow = data.shape[0]
        data_indices = list(range(nrow))
        training_data_count = int(nrow * self.training_data_percent)
        np.random.shuffle(data_indices)
        training_data_indices, test_data_indices = data_indices[training_data_count:], data_indices[:]
        for i in range(self.iterations):
            np.random.shuffle(training_data_indices)
            evaluator.process_training_data(data[training_data_indices,:], expected_values[training_data_indices,:], i, *algorithm_specific_objects)
        evaluator.process_test_data(data[test_data_indices,:], expected_values[test_data_indices,:], self.iterations + 1, *algorithm_specific_objects)

class KFoldingCrossValidation(TrainingStrategy):

    def __init__(self, iterations, folds, training_data_percent):
        super().__init__(iterations, training_data_percent)
        self.__folds = folds

    def train(self, evaluator, data, expected_values, *algorithm_specific_objects):
        nrow = data.shape[0]
        data_per_fold = int(nrow / self.__folds)

        if data_per_fold < 2:
            raise AttributeError("Too few data to evaluate!")

        data_indices = list(range(nrow))
        np.random.shuffle(data_indices)
        iterations_per_fold = int(self.iterations / self.__folds)
        training_data_count = int(nrow * self.training_data_percent)

        for fold_idx in range(self.__folds):
            fold_indices = data_indices[:data_per_fold]
            data_indices = data_indices[data_per_fold:]
            training_data_indices, test_data_indices = fold_indices[:training_data_count], fold_indices[training_data_count:]
            iteration_no_offset = fold_idx * iterations_per_fold
            for i in range(iterations_per_fold):
                np.random.shuffle(training_data_indices)
                iteration_no = iteration_no_offset + i
                evaluator.process_training_data(data[training_data_indices,:], expected_values[training_data_indices,:], iteration_no, *algorithm_specific_objects)
            evaluator.process_test_data(data[test_data_indices,:], expected_values[test_data_indices,:], iteration_no_offset + 1, *algorithm_specific_objects)

