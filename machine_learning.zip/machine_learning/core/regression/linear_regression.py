__author__ = 'Filip'

import numpy as np


class PolynaomialRegressionSolver():

    def __init__(self, learning_rate, iterations = 1000):
        self.__iterations = iterations
        self.__learning_rate = learning_rate

    def predict_weights(self, data, expected, initial_weights = None):
        nrow, ncol = data.shape
        ones = np.ones((nrow, 1))
        x = np.concatenate((ones, data), axis=1)
        weights = initial_weights
        if weights is None:
            weights = self.__prepare_weights(x.shape[1])
        nrow, ncol = x.shape
        for i in range(self.__iterations):
            actual = np.sum(x * weights, axis=1).reshape((nrow, 1))
            diffs = expected - actual
            if np.all(diffs < 0.0001):
                break
            for i in range(ncol):
                updates = diffs.T.dot(x[:, i].reshape((nrow, 1)))
                sum_of_updates = self.__learning_rate * np.sum(updates) / nrow
                weights[0,i] += sum_of_updates
        return weights

    def __prepare_weights(self, ncol):
        return np.random.rand(1, ncol)