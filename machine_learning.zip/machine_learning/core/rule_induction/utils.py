__author__ = 'Filip'

def hamming_distance(example1, example2):
    distance = 0
    for idx, value in enumerate(example1):
        if example2[idx] != value:
            distance += 1
    return distance


def partial_covering_metric(rule, example):
    covering_value = 1.0
    for complex in rule.antecedents:
        complex_covering_value = 1.0
        for selector in complex.selectors:
            if not selector.covers_example(example):
                complex_covering_value *= selector.covering_percentage
        covering_value *= complex_covering_value
    return covering_value
