__author__ = 'Filip'

import pandas as pd
import core.rule_induction.utils as utils
import core.rule_induction.models as models
import scipy.spatial.distance as dist


class HeuristicSearchData():

    def __init__(
            self,
            training_data,
            already_used_examples,
            rules_so_far,
            already_used_positive_seeds,
            numeric_columns,
            value_column):
        """
        DTO class for transferring information for seeds searching heuristic methods
        :type training_data: pandas.DataFrame
        :type already_used_examples: list
        :type rules_so_far: core.rule_induction.models.Rule
        :type already_used_positive_seeds: list
        :type numeric_columns: pandas.core.index.Index
        :type value_column: string
        :return:
        """
        self.training_data = training_data
        self.already_used_examples = already_used_examples
        self.rules_so_far = rules_so_far
        self.value_column = value_column
        self.already_used_positive_seeds = already_used_positive_seeds
        self.numeric_columns = numeric_columns


def covering_metric_based_positive_seed_heuristic_selector(
        example_indices,
        heuristic_search_data):
    """
    Searches for positive seed which will be least covered by the existing rules. Seeds selected using this heuristic
    are more likely to be much different than the previous ones, resulting in the wider covering of the examples space.
    Returns index of new positive seed in a data frame.
    :type example_indices: pandas.DataFrame
    :type heuristic_search_data: HeuristicSearchData
    :return:
    """
    lowest_covering_metric = float("inf")
    positive_seed_idx = -1
    rules_grouped_by_class = dict()
    for rule in heuristic_search_data.rules_so_far:
        value = rule.consequent.value
        rules_grouped_by_class.setdefault(value, [])
        rules_grouped_by_class[value].append(rule)
    for example_idx in example_indices:
        current_example = heuristic_search_data.training_data.loc[example_idx, :]
        example_class = current_example[heuristic_search_data.value_column]
        rules_covering_class = rules_covering_class[example_class]
        covering_metric = sum([utils.partial_covering_metric(rule, current_example) for rule in rules_covering_class])
        if covering_metric < lowest_covering_metric:
            lowest_covering_metric = covering_metric
            positive_seed_idx = example_idx
    return positive_seed_idx


def dissimilarity_based_positive_seed_heuristic_selector(
        example_indices,
        heuristic_search_data):
    """
    Searches for positive seed which will be least similar to the previous ones (using hamming distance metric). Returns
    index of new positive seed in a data frame
    :type example_indices: pandas.DataFrame
    :type heuristic_search_data: HeuristicSearchData
    :return: int
    """
    biggest_difference = -float("inf")
    positive_seed_idx = -1
    seeds_grouped_by_class = dict()
    excluded_columns = [heuristic_search_data.value_column]
    excluded_columns.extend(heuristic_search_data.numeric_columns)
    non_numeric_columns = heuristic_search_data.training_data.columns - excluded_columns
    for seed_idx in heuristic_search_data.already_used_positive_seeds:
        seed = heuristic_search_data.training_data.loc[seed_idx,:]
        seed_class = seed[heuristic_search_data.value_column]
        seeds_grouped_by_class.setdefault(seed_class, [])
        seeds_grouped_by_class[seed_class].append(seed)
    for example_idx in example_indices:
        current_example = heuristic_search_data.training_data.loc[example_idx, :]
        current_example_class = current_example[heuristic_search_data.value_column]
        if current_example_class in seeds_grouped_by_class:
            seeds_of_this_class = seeds_grouped_by_class[current_example_class]
            total_diff = 0
            for used_seed in seeds_of_this_class:
                distance = 0
                if any(non_numeric_columns):
                    distance += utils.hamming_distance(current_example[non_numeric_columns], used_seed[non_numeric_columns])
                if any(heuristic_search_data.numeric_columns):
                    distance += dist.euclidean(
                        current_example[heuristic_search_data.numeric_columns],
                        used_seed[heuristic_search_data.numeric_columns])
                total_diff += distance
            if total_diff > biggest_difference:
                biggest_difference = total_diff
                positive_seed_idx = example_idx
        else:
            return example_idx
    return positive_seed_idx


def trivial_positive_seed_heuristic_selector(
        example_indices,
        heuristic_search_data):
    return example_indices[0]

def similarity_based_negative_seed_heuristic_selector(
        positive_seed_idx,
        heuristic_search_data,
        already_used_negative_seeds=[]):
    """
    Searches for negative seed which is as much similar to positive seed as possible.
    :type positive_seed_idx: int
    :type heuristic_search_data: HeuristicSearchData
    :type already_used_negative_seeds: list
    :return: int
    """
    positive_seed = heuristic_search_data.training_data.loc[positive_seed_idx, :]
    positive_seed_class = positive_seed[heuristic_search_data.value_column]
    smallest_difference = float('inf')
    negative_seed_idx = -1
    excluded_columns = [heuristic_search_data.value_column]
    excluded_columns.extend(heuristic_search_data.numeric_columns)
    non_numeric_columns = heuristic_search_data.training_data.columns - excluded_columns
    for idx in heuristic_search_data.training_data.index:
        if idx in already_used_negative_seeds:
            continue
        example = heuristic_search_data.training_data.loc[idx, :]
        difference = 0
        if example[heuristic_search_data.value_column] != positive_seed_class:
            if any(non_numeric_columns):
                difference = utils.hamming_distance(positive_seed[non_numeric_columns], example[non_numeric_columns])
            if any(heuristic_search_data.numeric_columns):
                difference += dist.euclidean(positive_seed[heuristic_search_data.numeric_columns], example[heuristic_search_data.numeric_columns])
            if difference < smallest_difference:
                smallest_difference = difference
                negative_seed_idx = idx
    return negative_seed_idx


def trivial_negative_seed_heuristic(
        positive_seed_idx,
        heuristic_search_data,
        already_used_negative_seeds=[]):
    positive_seed_class = heuristic_search_data.training_data.loc[positive_seed_idx, heuristic_search_data.value_column]
    for example_idx in heuristic_search_data.training_data.index:
        if example_idx in already_used_negative_seeds:
            continue
        example = heuristic_search_data.training_data.loc[example_idx, :]
        if example[heuristic_search_data.value_column] != positive_seed_class:
            return example_idx

def rate_complexes_heuristic(
        complexes,
        positive_seed_idx,
        example_indices,
        heuristic_search_data
    ):
    """
    Finds best complex using a metric: number.of.covered.examples where class[x] == class[positive_seed] +
    number.of.covered.data where class[x] == class[positive_seed]
    number.of.covered.instances(all_data - examples) where class[x] != class[positive_seed]
    :param complexes: list
    :param positive_seed_idx: int
    :param example_indices: list
    :param heuristic_search_data: HeuristicSearchData
    :return: float
    """
    ratings = dict()
    non_example_indices = heuristic_search_data.training_data.index - example_indices
    positive_seed_class = heuristic_search_data.training_data.loc[positive_seed_idx,:][heuristic_search_data.value_column]
    for idx, complex in enumerate(complexes):
        score = 0
        for non_example_idx in non_example_indices:
            example = heuristic_search_data.training_data.loc[non_example_idx, :]
            example_class = example[heuristic_search_data.value_column]
            is_covered = complex.covers_example(example)
            if example_class == positive_seed_class and is_covered: score += 1
            elif example_class != positive_seed_class and not is_covered: score += 1
        ratings[complex] = score
    return [pair[0] for pair in sorted(ratings.items(), key=lambda pair: pair[1], reverse=True)]


def trivial_rate_complexes_heuristic(
        complexes,
        positive_seed_idx,
        example_indices,
        heuristic_search_data
    ):
    """
    Finds best complex using a metric: number.of.covered.examples where class[x] == class[positive_seed] +
    number.of.covered.data where class[x] == class[positive_seed]
    number.of.covered.instances(all_data - examples) where class[x] != class[positive_seed]
    :param complexes: list
    :param positive_seed_idx: int
    :param example_indices: list
    :param heuristic_search_data: HeuristicSearchData
    :return: float
    """
    ratings = dict()
    non_example_indices = heuristic_search_data.training_data.index - example_indices
    positive_seed_class = heuristic_search_data.training_data.loc[positive_seed_idx,:][heuristic_search_data.value_column]
    for idx, complex in enumerate(complexes):
        score = 0
        for example_idx in example_indices:
            example = heuristic_search_data.training_data.loc[example_idx, :]
            example_class = example[heuristic_search_data.value_column]
            is_covered = complex.covers_example(example)
            if is_covered and example_class == positive_seed_class:
                score += 1
        ratings[complex] = score
    return [pair[0] for pair in sorted(ratings.items(), key=lambda pair: pair[1], reverse=True)]