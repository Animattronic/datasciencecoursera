__author__ = 'Filip'

from enum import Enum
import core.rule_induction.exceptions as exceptions
import operator as opr

class AllowedValues(Enum):
    NoneAllowed = 0
    AnyAllowed = 1


class NumericAttributeDomain():

    def __init__(self, min, max, step=1, is_real=True):
        self.min = min
        self.max = max
        self.step = step
        self.is_real = is_real

    def is_in(self, value):
        return self.min <= value <= self.max

    def next(self, value):
        if not self.is_in(value):
            raise exceptions.ValueNotInAttributeDomainException()
        return value + self.step

    def prev(self, value):
        if not self.is_in(value):
            raise exceptions.ValueNotInAttributeDomainException()
        return value - self.step


class AttributeValueProposition():

    def __init__(self, attribute_name, value):
        """
        :type attribute_name: str
        :type value: object
        """
        self.attribute_name = attribute_name
        self.attribute_value = value


class ComplexCoveringData():

    def __init__(self, positive_covered_indices, negative_covered_indices):
        """
        :type positive_covered_indices: set
        :set negative_covered_indices: set
        """
        self.positive_covered_indices = positive_covered_indices
        self.negative_covered_indices = negative_covered_indices

    @property
    def all_covered_examples(self):
        return self.positive_covered_indices.union(self.negative_covered_indices)


class Selector():

    def __init__(self, attr_name, *allowed_values, covering_percentage=1.0):
        """
        Creates attribute selector with a given set of allowed values.
        :type attr_name: str
        :type allowed_values: list
        :type covering_percentage: float
        """
        self.__attr_name = attr_name
        self.__allowed_values = set(allowed_values)
        self.__covering_percentage = covering_percentage

    @property
    def attribute_name(self):
        return self.__attr_name

    @property
    def allowed_values(self):
        return self.__allowed_values

    def covers_example(self, example):
        if AllowedValues.NoneAllowed in self.allowed_values:
            return False
        if AllowedValues.AnyAllowed in self.allowed_values:
            return True
        else:
            return self._perform_evaluation(example[self.attribute_name])

    def intersect(self, other):
        if not(isinstance(other, Selector)):
            raise exceptions.IncompatibleClassesForIntersectionException()
        if self.attribute_name != other.attribute_name:
            raise(str.format("Cannot intersect selector for attribute {0} with a selector for attribute {1}",
                             self.attribute_name, other.attribute_name))
        return self._perform_intersection(other)

    def _perform_intersection(self, other):
        raise NotImplementedError()

    def _perform_evaluation(self, example):
        raise NotImplementedError()

    def __eq__(self, other):
        if not(isinstance(other, Selector)):
            return False
        return self.allowed_values == other.allowed_values and self.attribute_name == other.attribute_name

    def __hash__(self):
        return hash(self.__attr_name) + \
               hash(sum([hash(allowed_value for allowed_value in self.__allowed_values)])) + \
               hash(self.__covering_percentage)


class Inclusion(Selector):
    """
    Class representing selector of discrete values. Checks if passed discrete value is included in allowed values set
    """

    def __init__(self, attribute_name, *allowed_values, covering_percentage=1.0):
        super().__init__(attribute_name, *allowed_values, covering_percentage=covering_percentage)

    def _perform_evaluation(self, example_value):
        return example_value in self.allowed_values

    def _perform_intersection(self, other):
        """
        Performs intersection with other selector
        :type other: core.rule_induction.models.Selector
        :return: core.rule_induction.models.Selector
        """
        all_allowed_values = self.allowed_values.union(other.allowed_values)
        if AllowedValues.AnyAllowed in all_allowed_values:
            return Inclusion(self.attribute_name, *[val for val in all_allowed_values if not val == AllowedValues.AnyAllowed])
        if AllowedValues.NoneAllowed in all_allowed_values:
            return Inclusion(self.attribute_name, AllowedValues.NoneAllowed)
        common_allowed_values = set(self.allowed_values) & set(other.allowed_values)
        return Inclusion(self.attribute_name, *common_allowed_values)

    def __repr__(self):
        return str.format("{0}=[{1}]", self.attribute_name, ",".join(self.allowed_values))


class NumericSelector(Selector):
    """
    Represents abstract base class for all numeric selectors. Allows only numeric values to be passed
    """

    def __init__(self, attribute_name, threshold, operator, covering_percentage=1.0):
        if not isinstance(threshold, (int, float)):
            raise exceptions.ValuePassedIsNotANumberException()
        super().__init__(attribute_name, threshold, covering_percentage=covering_percentage)
        self.operator = operator

    @property
    def threshold(self):
        return list(self.allowed_values)[0]

    def _perform_evaluation(self, example_value):
        return self.operator(example_value, self.threshold)

    def _perform_intersection(self, other):
        if isinstance(other, NumericSelector):
            vals = sorted([(self.threshold, self.operator), (other.threshold, other.operator)], key=lambda elem: elem[0])
            if other.operator in [opr.__lt__, opr.__le__]:
                return NumericSelector(self.attribute_name, vals[0][0], vals[0][1])
            elif other.operator in [opr.__ge__, opr.__gt__]:
                if vals[0][1] in [opr.__ge__, opr.__gt__]:
                    return Range(self.attribute_name, vals[0][0], vals[1][0], vals[0][1], vals[1][1])
                else:
                    return Inclusion(self.attribute_name, AllowedValues.NoneAllowed)
            else:
                raise exceptions.IncompatibleOperatorsClassException()
        elif isinstance(other, Range):
            vals = sorted([
                          (self.threshold, self.operator, self),
                          (other.range_start, other.start_operator, other),
                          (other.range_end, other.end_operator, other)],
                          key=lambda elem: elem[0])
            for idx, tpl in enumerate(vals):
                value = tpl[0]
                operator = tpl[1]
                source = tpl[2]
                if operator in [opr.__gt__, opr.__ge__] and idx != (len(vals)-1) and source == self:
                    return Range(self.attribute_name, value, vals[-1][0], operator, vals[-1][1])
                if operator in [opr.__lt__, opr.__le__] and 0 < idx < (len(vals)-1) and source == self:
                    return Range(self.attribute_name, vals[0][0], value, vals[0][1], operator)
                if operator in [opr.__lt__, opr.__le__] and idx == (len(vals)-1) and source == self:
                    return Range(self.attribute_name, vals[0][0], vals[-2][0], vals[0][1], vals[-2][1])
            return Inclusion(self.attribute_name, AllowedValues.NoneAllowed)
        else:
            raise exceptions.IncompatibleClassesForIntersectionException()


class Range(Selector):

    def __init__(self, attribute_name, range_start, range_end, start_operator, end_operator, covering_percentage=1.0):
        if not(isinstance(range_start, (int, float)) or isinstance(range_end, (int, float))):
            raise exceptions.ValuePassedIsNotANumberException()
        if not {start_operator, end_operator}.issubset([opr.__lt__, opr.__le__, opr.__ge__, opr.__gt__]):
            raise exceptions.InvlidOperatorException()
        super().__init__(attribute_name, range_start, range_end, covering_percentage=covering_percentage)
        self.range_start = min(range_start, range_end)
        self.start_operator = start_operator

        self.range_end = max(range_start, range_end)
        self.end_operator = end_operator

    def _perform_evaluation(self, example_value):
        return self.start_operator(example_value, self.range_start) and self.end_operator(example_value, self.range_end)

    def _perform_intersection(self, other):
        if isinstance(other, Range):
            common_elements = sorted(
                list(set(range(self.range_start, self.range_end + 1)) & set(range(other.range_start, other.range_end + 1)))
            )
            if not any(common_elements):
                return Inclusion(self.attribute_name, AllowedValues.NoneAllowed)
            new_start_operator = self.start_operator if common_elements[0] == self.range_start else other.start_operator
            new_end_operator = self.end_operator if common_elements[-1] == self.end_operator else other.end_operator
            return Range(self.attribute_name, common_elements[0], common_elements[-1], new_start_operator, new_end_operator)
        else:
            return other.intersect(self)

    def __eq__(self, other):
        if not(isinstance(other, Range)):
            return False
        super_res = super().__eq__(other)
        if super_res:
            return self.start_operator == other.start_operator and self.end_operator == other.end_operator
        else:
            return super_res


class Complex():

    def __init__(self, *selectors):
        self.__attribute_selectors = {selector.attribute_name: selector for selector in selectors}

    @property
    def covered_attributes(self):
        return set(self.__attribute_selectors.keys())

    @property
    def selectors(self):
        return list(self.__attribute_selectors.values())

    def attribute_selector(self, attribute_name):
        if attribute_name in self.__attribute_selectors:
            return self.__attribute_selectors[attribute_name]
        else:
            return Inclusion(attribute_name, AllowedValues.AnyAllowed)

    def covers_example(self, example):
        return all([selector.covers_example(example) for selector in self.__attribute_selectors.values()])

    def intersect(self, other):
        if not(isinstance(other, Complex)):
            raise exceptions.IncompatibleClassesForIntersectionException()
        all_covered_attributes = self.covered_attributes.union(other.covered_attributes)
        new_selectors = []
        for attribute in all_covered_attributes:
            new_selectors.append(self.attribute_selector(attribute).intersect(other.attribute_selector(attribute)))
        return Complex(*new_selectors)

    def is_empty(self):
        return all([selector.allowed_values == {AllowedValues.NoneAllowed} for selector in self.selectors])

    def is_universal(self):
        return all([selector.allowed_values == [AllowedValues.AnyAllowed] for selector in self.selectors])

    def __eq__(self, other):
        if not isinstance(other, Complex):
            return False
        if not self.covered_attributes == other.covered_attributes:
            return False
        return all([other.attribute_selector(attr) == self.__attribute_selectors[attr] for attr in self.covered_attributes])

    def __hash__(self):
        return sum([hash(selector) for selector in self.__attribute_selectors])

    def __repr__(self):
        results = []
        for selector in self.selectors:
            results.append(str(selector))
        return str.format("<{0}>", ";".join(results))


class UniversalComplex(Complex):

    def __init__(self):
        super().__init__()

    @property
    def is_universal(self):
        return True

    @property
    def is_empty(self):
        return False

    def attribute_selector(self, attribute_name):
        return Inclusion(attribute_name, AllowedValues.AnyAllowed)

    def covers_example(self, example):
        return True

    def intersect(self, other):
        if not(isinstance(other, Complex)):
            raise exceptions.IncompatibleClassesForIntersectionException()
        if isinstance(other, UniversalComplex):
            return self
        selectors = []
        for covered_attribute in other.covered_attributes:
            selector_for_attr = other.attribute_selector(covered_attribute)
            selectors.append(Inclusion(covered_attribute, *selector_for_attr.allowed_values))
        return Complex(*selectors)


class EmptyComplex(Complex):
    def __init__(self):
        super().__init__([])

    @property
    def is_universal(self):
        return False

    @property
    def is_empty(self):
        return True

    def attribute_selector(self, attribute_name):
        return Selector(attribute_name, AllowedValues.NoneAllowed)

    def covers_example(self, example):
        return False

    def intersect(self, other):
        if not(isinstance(other, Complex)):
            raise exceptions.IncompatibleClassesForIntersectionException()
        return EmptyComplex()


class Rule():

    def __init__(self, consequent, *antecedents):
        """

        :type consequent: AttributeValueProposition
        :type antecedents: *Complex
        :return:
        """
        self.antecedents = antecedents
        self.consequent = consequent

    def covers_example(self, example):
        return any([antecedent.covers_example(example) for antecedent in self.antecedents])

    def __eq__(self, other):
        if not isinstance(other, Rule):
            return False
        return self.consequent == other.consequent and all(
            [
                antecedent in other.antecedents
                for antecedent in self.antecedents
            ])

    def __repr__(self):
        results = []
        for complex in self.antecedents:
            results.append(str(complex))
        return str.format("({0})", ";".join(results))


class UnorderedRulesSet():

    def __init__(self, *rules):
        self.rules = list(rules)

    def add_rule(self, new_rule):
        self.rules.append(new_rule)


class RulesList():

    def __init__(self, *rules):
        self.rules = list(rules)

    def add_rule(self, new_rule):
        self.rules.append(new_rule)