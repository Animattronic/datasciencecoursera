__author__ = 'Filip'

import pandas as pd
import core.rule_induction.models as models
import core.rule_induction.heuristics as heuristics
import operator as opr


class SequentialCovering():

    def learn_rules(self, training_data, value_column, discrete_domains, numeric_domains):
        example_indices = training_data.index
        rules = self.build_rules_container()
        learning_metadata = self.build_learning_metadata(training_data, value_column, numeric_domains, discrete_domains)
        complexes_covering_data = dict()
        while any(example_indices):
            complex = self.find_complex(training_data, example_indices, value_column, discrete_domains, numeric_domains, learning_metadata)
            category = self.get_category(complex, training_data, example_indices, value_column, learning_metadata)
            consequent = models.AttributeValueProposition(value_column, category)
            new_rule = models.Rule(consequent, complex)
            examples_to_remove = []
            for example_idx in training_data.index:
                example = training_data.loc[example_idx, :]
                if new_rule.covers_example(example):
                    examples_to_remove.append(example_idx)
            example_indices = example_indices - examples_to_remove
            self.add_rule_to_container(rules, new_rule, learning_metadata)
        return rules

    def find_complex(
            self,
            training_data,
            example_indices,
            value_column,
            discrete_attributes_domains,
            numeric_attributes_domains,
            learning_metadata):
        raise NotImplementedError()

    def get_category(self, complex, training_data, example_indices, value_column, learning_metadata):
        covered_classes = dict()
        for example_idx in training_data.index:
            example = training_data.loc[example_idx, :]
            if complex.covers_example(example):
                covered_classes.setdefault(example[value_column], 0)
                covered_classes[example[value_column]] += 1
        return sorted(covered_classes.items(), key=lambda pair: pair[1], reverse=True)[0][0]

    def build_rules_container(self):
        raise NotImplementedError()

    def add_rule_to_container(self, container, rule, learning_metadata):
        raise NotImplementedError()

    def build_learning_metadata(self, training_data, value_column, numeric_domains, discrete_domains):
        raise NotImplementedError()


class AQMetadata():

    def __init__(
            self,
            already_used_positive_seeds=[],
            training_data=[],
            already_used_examples=[],
            rules_so_far=[],
            numeric_columns=[],
            value_column=None):
        self.already_used_positive_seeds = already_used_positive_seeds
        self.training_data = training_data
        self.already_used_examples = already_used_examples
        self.rules_so_far = rules_so_far
        self.numeric_columns = numeric_columns
        self.value_column = value_column


class AQAlgorithm(SequentialCovering):

    def __init__(self, positive_seed_selector, negative_seed_selector, complex_rating_heuristic, beam_size=1):
        self.__positive_seed_selector = positive_seed_selector
        self.__negative_seed_selector = negative_seed_selector
        self.__complex_rating_heuristic = complex_rating_heuristic
        self.__beam_size = beam_size

    def partial_star(self, positive_seed_idx, negative_seed_idx, data, discrete_domains, numeric_domains):
        """
        Tries to build partial star basing on the positive seed and negative seed. Uses attribute domains for all
         possible attributes on data
        :type data: pandas.DataFrame
        :type positive_seed_idx: int
        :type negative_seed_idx: int
        :type discrete_domains: dict
        :type numeric_domains: dict
        :return: list
        """
        positive_seed = data.loc[positive_seed_idx, :]
        negative_seed = data.loc[negative_seed_idx, :]
        complexes = []
        for attribute, domain in discrete_domains.items():
            reduced_domain = domain.difference([negative_seed[attribute]])
            if any(reduced_domain) and positive_seed[attribute] in reduced_domain:
                complexes.append(models.Complex(models.Inclusion(attribute, *reduced_domain)))
        return complexes

    def find_complex(
            self,
            training_data,
            example_indices,
            value_column,
            discrete_attributes_domains,
            numeric_attributes_domains,
            learning_metadata):
        positive_seed_idx = self.__positive_seed_selector(example_indices, learning_metadata)
        positive_seed_class = training_data.loc[positive_seed_idx, value_column]
        already_used_negative_seeds = []
        complexes = {models.UniversalComplex(): set(training_data.index)}
        while self.any_negative_complex_is_covered(training_data, positive_seed_class, value_column, complexes):
            negative_seed_idx = self.__negative_seed_selector(positive_seed_idx, learning_metadata, already_used_negative_seeds)
            already_used_negative_seeds.append(negative_seed_idx)
            partial_star = self.partial_star(positive_seed_idx, negative_seed_idx, training_data, discrete_attributes_domains, numeric_attributes_domains)
            if not any(partial_star):
                return [models.EmptyComplex]
            else:
                intersected_partial_star = self.intersect_new_partial_star_and_complexes_so_far(partial_star, complexes, training_data)
                complexes = self.create_beam(intersected_partial_star, positive_seed_idx, example_indices, learning_metadata)
        return self.__complex_rating_heuristic(
            complexes.keys(),
            positive_seed_idx,
            example_indices,
            learning_metadata)[0]

    def remove_less_general_complexes(self, complexes_covering):
        """
        Removes each complex which is less general than some other: if examples covered by a complex are subset of other
        complex.
        :type complexes_covering: dict
        :return: dict
        """
        complexes_to_remove = set()
        for current_complex, covered_examples in complexes_covering.items():
            if current_complex in complexes_to_remove:
                continue
            for other_complex, other_covered_examples in complexes_covering.items():
                if other_complex == current_complex or other_complex in complexes_to_remove:
                    continue
                if covered_examples.issubset(other_covered_examples):
                    complexes_to_remove.add(current_complex)
        return {complex: covered_data for complex, covered_data in complexes_covering.items() if not complex in complexes_to_remove}

    def any_negative_complex_is_covered(self, training_data, positive_seed_class, value_column, complexes):
        for exmaple_idx in training_data.index:
            example = training_data.loc[exmaple_idx, :]
            if example[value_column] != positive_seed_class and any([complex.covers_example(example) for complex in complexes]):
                return True
        return False

    def intersect_new_partial_star_and_complexes_so_far(self, new_partial_star, complexes_so_far, training_data):
        new_complexes_covering = dict()
        for complex, _ in complexes_so_far.items():
            for partial_star_complex in new_partial_star:
                intersected_complex = complex.intersect(partial_star_complex)
                positive_covered_indexes = set()
                for example_idx in training_data.index:
                    example = training_data.loc[example_idx, :]
                    if intersected_complex.covers_example(example):
                        positive_covered_indexes.add(example_idx)
                new_complexes_covering[intersected_complex] = positive_covered_indexes
        return self.remove_less_general_complexes(new_complexes_covering)

    def create_beam(self, reduced_partial_star, positive_seed_idx, example_indices, learning_metadata):
        ordered_best_complexes = self.__complex_rating_heuristic(
            reduced_partial_star.keys(),
            positive_seed_idx,
            example_indices,
            learning_metadata)
        #TODO: temp solution, fixit!!!
        return {ordered_best_complexes[-1]:reduced_partial_star[ordered_best_complexes[-1]]}
        #return {complex:reduced_partial_star[complex] for complex in ordered_best_complexes[:self.__beam_size]}

    def build_rules_container(self):
        return models.UnorderedRulesSet()

    def add_rule_to_container(self, container, rule, learning_metadata):
        learning_metadata.rules_so_far.append(rule)
        container.add_rule(rule)

    def build_learning_metadata(self, training_data, value_column, numeric_domains, discrete_domains):
        return AQMetadata(
            already_used_positive_seeds=[],
            training_data=training_data,
            already_used_examples=[],
            rules_so_far=[],
            numeric_columns=list(numeric_domains.keys()),
            value_column=value_column)