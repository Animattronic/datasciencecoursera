__author__ = 'Filip'

class InvalidNumberOfParametersException(Exception):

    def __init__(self):
        super().__init__("Invalid numer of parameters passed!")


class ValuePassedIsNotANumberException(Exception):

    def __init__(self):
        super().__init__("Value passed is not a number!")


class IncompatibleOperatorsClassException(Exception):

    def __init__(self):
        super().__init__("Incompatible types of operators for intersection")


class IncompatibleClassesForIntersectionException(Exception):

    def __init__(self):
        super().__init__("Incompatible classes for intersection!")


class InvalidOperatorException(Exception):

    def __init__(self):
        super().__init__("Invalid operator!")


class ValueNotInAttributeDomainException(Exception):

    def __init__(self):
        super().__init__("Value is not in attribute domain!")

