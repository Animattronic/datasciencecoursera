__author__ = 'Filip'

import numpy as np
import scipy.spatial.distance as dist

def mean_square_errors(expected, actual):
    euclidean = dist.euclidean(expected, actual)
    return euclidean / len(expected)

def softmax_error_calculation(expected, actual):
    max_index_expected = np.argmax(expected)
    max_index_actual = np.argmax(actual)
    if(max_index_expected == max_index_actual):
        return 0
    else:
        return 1