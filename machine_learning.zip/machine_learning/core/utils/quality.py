__author__ = 'Filip'

import pandas as pd
import numpy as np
from copy import deepcopy

class DataQuality():
    """
    Allows tracking errors in
    """

    def __init__(self, error, iteration):
        self.__error = error
        self.__iteration = iteration

    @property
    def error(self):
        return self.__error

    @property
    def iteration(self):
        return self.__iteration


class ContingencyTable():

    #TODO: check it later!!!

    def __init__(self, classess):
        classess.append("summary")
        self.__classification_data = pd.DataFrame(data=np.ones((len(classess), len(classess))), index=classess, columns=classess)

    def observation(self, element, true_value):
        self.__classification_data.loc[element, true_value] += 1
        self.__classification_data.loc[element, "summary"] += 1
        self.__classification_data.loc['summary', element] += 1

    @property
    def table(self):
        return deepcopy(self.__classification_data)

class QualityLogger():

    def __init__(self):
        self.__entries = []

    @property
    def entries(selfs):
        return self.__entries

    def log(self, data_quality):
        self.__entries.append(data_quality)

    def log(self, error, iteration):
        self.__entries.append(DataQuality(error, iteration))

class ClassificationQualityLogger(QualityLogger):

    def __init__(self):
        super().__init__()
