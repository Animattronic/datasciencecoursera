__author__ = 'Filip'

import numpy as np
import math
import scipy.spatial.distance as dist

class Evaluator():

    def evaluate(self, data, selected_features, values):
        raise NotImplementedError()

class KnnEvaluator(Evaluator):

    def __init__(self, knn_algorithm, neighbors_count, error_function = dist.euclidean):
        super().__init__()
        self.knn_algorithm = knn_algorithm
        self.neighbors_count = neighbors_count
        self.error_function = error_function

    def evaluate(self, data, selected_features, values):
        results = np.ones((data.shape[0], 1))
        nrow, ncol = data.shape
        error = 0
        for i in range(data.shape[0]):
            vector = data[i, :]
            vector_to_evaluate = vector[0, selected_features]
            vectors_to_take = list(range(nrow))
            vectors_to_take.remove(i)
            expected = values[i, 0]
            actual = self.knn_algorithm.process_query(data[[[vec_to_take] for vec_to_take in vectors_to_take], selected_features], values, vector_to_evaluate, self.neighbors_count)
            error += math.pow(expected - actual, 2)
        return error / data.shape[0]

    def evaluate_query(self, data, values, row, expected_value):
        actual_value = self.knn_algorithm.process_query(data, values, row, self.neighbors_count)
        return self.error_function(expected_value, actual_value)

class FeatureSelector():

    def __init__(self, evaluator):
        self.evaluator = evaluator

    def select_features(self, data, expected_values):
        raise NotImplementedError()

class InstancesSelector():

    def __init__(self, evaluator):
        self.evaluator = evaluator

    def select_instances(self, data, expected_values):
        raise NotImplementedError()

class ForewardSelector(FeatureSelector):

    def __init__(self, evaluator):
        self.evaluator = evaluator

    def select_features(self, data, values):
        lowest_error = []
        best_feature = 0
        lowest_error = float("inf")

        nrow, ncol = data.shape
        all_features = set(list(range(ncol)))
        selected_features = set()

        while not (best_feature is None) and (len(selected_features) != ncol):
            best_feature = None
            for feature in (all_features - selected_features):
                new_features = set(selected_features)
                new_features.add(feature)
                error = self.evaluator.evaluate(data, list(new_features), values)
                if error < lowest_error:
                    lowest_error = error
                    best_feature = feature
            if not (best_feature is None):
                selected_features.add(best_feature)
        return selected_features

class InstancesSelector(InstancesSelector):

    def __init__(self, evaluator, error_threshold):
        super().__init__(evaluator)
        self.__error_threshold = error_threshold

    def select_instances(self, data, expected_values):
        indices_to_take = []
        nrow, ncol = data.shape
        for i in range(nrow):
            row = data[i, :]
            expected_value = expected_values[i, :]
            data_to_take = data[indices_to_take]
            values_to_take = expected_values[indices_to_take]
            if any(indices_to_take):
                error_level = self.evaluator.evaluate_query(data_to_take, values_to_take, row, expected_value)
                if error_level > self.__error_threshold:
                    indices_to_take.append(i)
            else:
                indices_to_take.append(i)
        return indices_to_take


