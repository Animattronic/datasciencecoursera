__author__ = 'Filip'

import numpy as np
import scipy.signal as sgn
import scipy.spatial.distance as dist
import math

def squared_inverse_of_distance_weight(distance):
    return 1/math.pow(distance, 2)

def gaussian_weight(distance, sigma=10.0):
    val = math.pow(-distance, 2)/(2 * math.pow(sigma, 2))
    return math.exp(val)

class KnnClassifier():

    def __init__(self, distance_measure, weight_function):
        self.distance_measure = distance_measure
        self.weight_function = weight_function

    def process_query(self,
                      data,
                      values,
                      query,
                      k,
                      feature_weights = None,
                      get_indices = None):

        if feature_weights:
            data = data * feature_weights

        if get_indices:
            data = data[get_indices,:]

        weights = dict()
        nrow, ncol = data.shape
        for i in range(len(data)):
            data_vector = data[i,:]
            non_values_vector = data_vector[0, :]
            weights[i] = self.weight_function(self.distance_measure(query, non_values_vector))
        sorted_distances = sorted(weights, key=weights.get, reverse=True)
        indices_to_get = sorted_distances[:k]
        neighbors = [ (weights[vec_idx], values[vec_idx, 0]) for vec_idx in indices_to_get]
        return self.classify(neighbors)

    def classify(self, selected_neighbors):
        nominator = 0
        denominator = 0
        for neighbor in selected_neighbors:
            weight, value = neighbor[0], neighbor[1]
            denominator += weight
            nominator += weight * value
        return nominator/ denominator